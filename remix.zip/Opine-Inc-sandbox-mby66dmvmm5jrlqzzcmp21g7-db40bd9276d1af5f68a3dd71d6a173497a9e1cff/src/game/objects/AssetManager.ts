
// src/game/objects/AssetManager.ts

import { Scene } from 'phaser';
import { Item } from '../config/mergeDataFull';

export interface ItemAsset {
  key: string;
  url: string;
  displaySize?: { width: number; height: number };
  scale?: number;
}

export class AssetManager {
  private scene: Scene;
  private itemAssets: Map<Item, ItemAsset> = new Map();
  private loadedAssets: Set<string> = new Set();

  constructor(scene: Scene) {
    this.scene = scene;
    this.initializeAssets();
  }

  private initializeAssets() {
    // Register item assets here
    this.registerAsset('Mop', {
      key: 'mop_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Mop%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-0Rllm47amMc5FJ1YYSVppCf8Q9yVnx.5d-0',
      scale: 0.5 // Increased from 0.25 to make assets larger and clearer
    });

    this.registerAsset('Loose Wires', {
      key: 'loose_wires_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Loose%20Wires%22%20%20just%20a%20pile%20of%20wires%2C%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-Dctj0vehiJJX4FhO2VEzZ6Prv6OnQU.5d-0',
      scale: 0.5 // Increased from 0.25 to make assets larger and clearer
    });

    this.registerAsset('Rubber Duck', {
      key: 'rubber_duck_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Rubber%20Duck%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-PvFuLRK9Kcr8se4WwSYmFuN2IHiklm.5d-0',
      scale: 0.5 // Increased from 0.25 to make assets larger and clearer
    });

    this.registerAsset('Fan Blade', {
      key: 'fan_blade_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Fan%20Blade%22%20just%201%20blade%20not%20the%20entire%20fan%2C%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-KiTQpjpscu6qf12HqaP8K04JnPwF3y.5d-2',
      scale: 0.5
    });

    this.registerAsset('Toilet Brush', {
      key: 'toilet_brush_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Toilet%20Brush%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-DHWilH7Hz2GgQJRwtgfyEuKTPFY0Pk.5d-0',
      scale: 0.5
    });

    this.registerAsset('Toilet Paper', {
      key: 'toilet_paper_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Toilet%20Paper%22%20just%201%20blade%20not%20the%20entire%20fan%2C%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-SYJCbR1Py98sYB7Pw1VpaI0U0amrRA.5d-1',
      scale: 0.5
    });

    this.registerAsset('Soap', {
      key: 'soap_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Soap%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-OSZesnJPp4UP0yLXcM8DIKcFUF0wkn.5d-0',
      scale: 0.5
    });

    this.registerAsset('Bucket', {
      key: 'bucket_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Bucket%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-6muHgpXHMdW2oMNtZReBU2GfxADs0S.5d-2',
      scale: 0.5
    });

    this.registerAsset('Towel', {
      key: 'towel_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Towel%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-pjPIYZniLB2w9kubLL85kVG6XWuy8u.5d-3',
      scale: 0.5
    });

    this.registerAsset('Energy Canister', {
      key: 'energy_canister_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Energy%20Canister%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-ucTd6MToNY5lCli6MjfsanFwA3m9Mv.5d-1',
      scale: 0.5
    });

    this.registerAsset('Goldfish Bowl', {
      key: 'goldfish_bowl_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Goldfish%20Bowl%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-sTCZ7zS4vPyvNMcLFTcB2UuydfxlWq.5d-0',
      scale: 0.5
    });

    this.registerAsset('Portal Shard', {
      key: 'portal_shard_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Portal%20Shard%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-A6dp5dm7mZIq1qN5jfjWa5MTfjWuLH.5d-0',
      scale: 0.5
    });

    this.registerAsset('Battery', {
      key: 'battery_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20-L6oEJkPsYhgclnv8Xw9FnK2Dw9tjPL.%20Rick%20and%20morty%20style%209%20volt%20battery%20no%20shadow%20no%20background-3',
      scale: 0.5
    });

    this.registerAsset('Plunger', {
      key: 'plunger_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20-9TGifL3Bo8Y1k2EJXnOaliJaEao7Po.%20Rick%20and%20morty%20style%20plunger%20with%20a%20face%20no%20shadow%20no%20ground%20no%20background-2',
      scale: 0.5
    });

    this.registerAsset('Sock', {
      key: 'sock_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Sock%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-CG0w8V233dGR4o0GCF9gIqlSUyBpQa.5d-0',
      scale: 0.5
    });

    this.registerAsset('Duct Tape', {
      key: 'duct_tape_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Duct%20Tape%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-ANR9sRNgmHPIETmpkLzRwmGIHs3VYt.5d-2',
      scale: 0.5
    });

    this.registerAsset('Toolkit', {
      key: 'toolkit_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22tool%20kit%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-2X54S3bbRtpgilzkqU00fbE5q2Sjjm.5d-0',
      scale: 0.5
    });

    this.registerAsset('Coolant Tank', {
      key: 'coolant_tank_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Coolant%20Tank%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-hD6ImhqB54Dmu1j2oBsyjTDYsVrsMn.5d%0A-2',
      scale: 0.5
    });

    this.registerAsset('Screw', {
      key: 'screw_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22screw%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-EyHFsBrFmVc2xvpgUbrFwQ6LnfVD55.5d-3',
      scale: 0.5
    });

    this.registerAsset('Wrench', {
      key: 'wrench_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22wrench%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-vraJu89JpLdkyf9PTXQXrgjatOUwy2.5d-0',
      scale: 0.5
    });

    this.registerAsset('Fuse', {
      key: 'fuse_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Rick%20and%20morty%20style%20%22FUSE%22%20%28like%20one%20that%20goes%20in%20a%20car%5D%20no%20shadows%20no%20background-0-Sihn5vGQnoWdQmhlOFxnPBGZ2ogEeA',
      scale: 0.5
    });

    this.registerAsset('Pipe', {
      key: 'pipe_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20-NAJhLYKrYJ9giJEhZgoVCYDVxzQYrq.%20Rick%20and%20morty%20style%20pipe%20%28like%20a%20lead%20pipe%29%20no%20shadows%20no%20background-3',
      scale: 0.5
    });

    this.registerAsset('Ham Sandwich', {
      key: 'ham_sandwich_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Ham%20Sandwich%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-CG0w8V233dGR4o0GCF9gIqlSUyBpQa.5d-0', // Using the Sock asset URL as a temporary fix
      scale: 0.5
    });

    this.registerAsset('Unstable Goo', {
      key: 'unstable_goo_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20-5oZXl4wPh90INtS5kNdVu2y4Rd5dJE.%20Rick%20and%20morty%20style%20unstable%20goo%20no%20shadows%20no%20background-0',
      scale: 0.5
    });

    this.registerAsset('Soggy Paper (Hazard: Slippery)', {
      key: 'soggy_paper_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Rick%20and%20morty%20style%20%22soggy%20toilet%20paper%22%20no%20people%20no%20shadows%20no%20background-1-yoD6JHs5ll309taZtzMspYarAxlrcm',
      scale: 0.5
    });

    this.registerAsset('Powered Wire', {
      key: 'powered_wire_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Rick%20and%20morty%20style%20bundle%20of%20%22Powered%20Wire%22%20electric%20wires%20with%20arcs%20of%20lightning%20arcs%20no%20shadows%20no%20background-0-NVLAh9ZxGlhZzcmcYW7gM8NImUl3US',
      scale: 0.5
    });

    this.registerAsset("THOR'S PLUNGER", {
      key: 'thors_plunger_asset',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Rick%20and%20morty%20style%20%22Shock%20Plunger%22%20a%20metal%20toilet%20plungers%20with%20electric%20arcs%20no%20shadows%20no%20background-3-T3NB9atfbZIGDiPymHCa4KhfowIqry',
      scale: 0.5
    });

    // Register goo splatter asset for when goos are destroyed
    this.registerAsset('Goo Splatter', {
      key: 'goo_splatter',
      url: 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-A%20splatter%20of%20green%20goo%2C%20cartoonish-W0Mt5IcK1nXkRIovNFBL1di1KivaGP.%20It%20should%20look%20like%20it%20is%20on%20a%20flat%20surface%20below%20eye%20level%20in%20single%20point%20perspective-3',
      scale: 0.6
    });

    // Add more assets here as they become available
  }

  private registerAsset(itemName: Item, asset: ItemAsset) {
    this.itemAssets.set(itemName, asset);
  }

  public hasAsset(itemName: Item): boolean {
    return this.itemAssets.has(itemName);
  }

  public getAsset(itemName: Item): ItemAsset | null {
    return this.itemAssets.get(itemName) || null;
  }

  public async loadAsset(itemName: Item): Promise<boolean> {
    const asset = this.getAsset(itemName);
    if (!asset) return false;

    // Check if already loaded
    if (this.loadedAssets.has(asset.key)) return true;

    // Check if the texture already exists in the cache (might have been loaded in preload)
    if (this.scene.textures.exists(asset.key)) {
      this.loadedAssets.add(asset.key);
      return true;
    }

    return new Promise((resolve) => {
      // Load the asset
      this.scene.load.image(asset.key, asset.url);
      
      // Set up completion handler
      this.scene.load.once('complete', () => {
        this.loadedAssets.add(asset.key);
        resolve(true);
      });

      this.scene.load.once('loaderror', () => {
        resolve(false);
      });

      // Start loading if not already in progress
      if (!this.scene.load.isLoading()) {
        this.scene.load.start();
      }
    });
  }

  public async loadAllAssets(): Promise<void> {
    const loadPromises: Promise<boolean>[] = [];
    
    for (const [itemName] of this.itemAssets) {
      loadPromises.push(this.loadAsset(itemName));
    }

    await Promise.all(loadPromises);
  }

  public createSprite(itemName: Item, x: number, y: number): Phaser.GameObjects.Sprite | null {
    const asset = this.getAsset(itemName);
    if (!asset) {
      return null;
    }

    // Check both our loaded assets set AND the scene's texture cache
    const isLoaded = this.loadedAssets.has(asset.key) || this.scene.textures.exists(asset.key);
    
    if (!isLoaded) {
      return null;
    }

    // Mark as loaded in our set if it exists in texture cache but not in our set
    if (this.scene.textures.exists(asset.key) && !this.loadedAssets.has(asset.key)) {
      this.loadedAssets.add(asset.key);
    }

    const sprite = this.scene.add.sprite(x, y, asset.key);
    
    // Set texture filtering to nearest neighbor to prevent blurriness when scaling
    const texture = this.scene.textures.get(asset.key);
    if (texture && texture.source && texture.source[0]) {
      texture.source[0].setFilter(Phaser.Textures.FilterMode.NEAREST);
    }
    
    // Apply display size or scale
    if (asset.displaySize) {
      sprite.setDisplaySize(asset.displaySize.width, asset.displaySize.height);
    } else if (asset.scale) {
      sprite.setScale(asset.scale);
      
      // Ensure the sprite doesn't exceed a maximum size (for gameplay balance)
      const maxSize = 80; // Increased from 50 to 80 pixels for better visibility
      const currentWidth = sprite.displayWidth;
      const currentHeight = sprite.displayHeight;
      
      if (currentWidth > maxSize || currentHeight > maxSize) {
        const scaleDown = maxSize / Math.max(currentWidth, currentHeight);
        sprite.setScale(asset.scale * scaleDown);
      }
    }

    return sprite;
  }

  public getLoadedAssets(): string[] {
    return Array.from(this.loadedAssets);
  }

  public getAllRegisteredItems(): Item[] {
    return Array.from(this.itemAssets.keys());
  }
}