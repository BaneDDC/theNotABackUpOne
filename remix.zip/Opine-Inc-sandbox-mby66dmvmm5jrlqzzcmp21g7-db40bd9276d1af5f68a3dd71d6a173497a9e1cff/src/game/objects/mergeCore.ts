
// src/game/objects/mergeCore.ts
// Self-contained merge loop (placeholders).
import Phaser from "phaser";
import {
  Item,
  getMergeResult,
  pickRandomTier1,
  getTier,
  isTier1,
  SPAWNABLE_TIER1,
  getTier1Partners,
} from "../config/mergeDataFull";
import { AssetManager } from "./AssetManager";

type LabeledRect = (Phaser.GameObjects.Rectangle | Phaser.GameObjects.Sprite) & {
  itemName?: Item;
  __label?: Phaser.GameObjects.Text;
  __visualSprite?: Phaser.GameObjects.Sprite; // For when we use rectangle + sprite combo
  __hoverTimer?: Phaser.Time.TimerEvent; // Timer for hover delay
  __isHovering?: boolean; // Track hover state
};

// Funny descriptions for items
const ITEM_DESCRIPTIONS: Record<string, string> = {
  // Tier 1 items
  "Plunger": "The hero of every bathroom emergency. Has seen things that would make a grown man cry.",
  "Toilet Paper": "Softer than a cloud, more precious than gold during a pandemic.",
  "Toilet Brush": "The unsung warrior of bathroom hygiene. Fights the good fight daily.",
  "Soap": "Slippery when wet, judgmental when you don't use it enough.",
  "Mop": "Professional floor dancer with a serious attitude about cleanliness.",
  "Bucket": "Simple, reliable, and surprisingly good at holding things. Revolutionary!",
  "Pipe": "Not the smoking kind. This one prefers to carry water and occasionally burst.",
  "Loose Wires": "Sparky's distant cousins. They're having an identity crisis.",
  "Battery": "Energizer bunny's life force. Contains 100% pure 'get up and go'.",
  "Fan Blade": "One blade to rule them all. Dreams of being part of a helicopter.",
  "Toolkit": "Contains everything you need except the thing you're actually looking for.",
  "Coolant Tank": "Keeps things chill. Literally. The ice queen of mechanical parts.",
  "Rubber Duck": "Debugging expert and bath time philosopher. Quacks under pressure.",
  "Goldfish Bowl": "Home sweet home for aquatic pets with 3-second attention spans.",
  "Sock": "The lone survivor of the great washing machine sock massacre.",
  "Ham Sandwich": "Portable happiness between two slices. May contain traces of joy.",
  "Portal Shard": "Fragment of interdimensional travel. Handle with existential care.",
  "Energy Canister": "Concentrated enthusiasm in a can. Side effects may include productivity.",
  "Towel": "Don't panic! Always know where your towel is. -Hitchhiker's Guide",
  "Wrench": "Turns nuts and bolts, occasionally turns your knuckles purple.",
  "Duct Tape": "The force has a light side, a dark side, and duct tape holding it together.",
  "Screw": "Gets screwed over more than anyone else in the toolbox.",
  "Fuse": "Short-tempered electrical component. Blows up when things get heated.",
  "Toilet": "The porcelain throne. Where all great ideas are born.",
  
  // Tier 2+ items
  "Powered Wire": "Wires with attitude and electrical personality disorders.",
  "THOR'S PLUNGER": "Mjolnir's bathroom-dwelling cousin. Only the worthy can unclog with it.",
  "Wet Mop": "A mop that's seen some stuff. Probably needs therapy.",
  "Electric Brush": "Gives your teeth the shock of their lives. Dentists hate this one trick!",
  "Reinforced Plunger": "When regular plunging just isn't enough. For industrial-strength problems.",
  "Soapy Mop": "Clean freak's dream tool. Leaves everything sparkling and judgmental.",
  "Bubble Wand": "Childhood magic in stick form. Makes everything better with bubbles.",
  "Sanitation Maul": "When cleaning requires brute force. Mess with the best, die like the rest.",
  "Charged Duck": "Rubber duck with electrical superpowers. Quacks with authority.",
  "Sticky Sock": "Lost its partner, gained adhesive properties. Clings to hope.",
  "Bandaged Towel": "First aid meets bathroom accessories. Patches up your problems.",
  "Chilled Pipe": "Cooler than the other side of the pillow. Ice cold delivery system.",
  "Makeshift Vent": "DIY air circulation. Not OSHA approved, but it works!",
  "Jury-Rigged Fan": "Engineering at its finest. Held together by hope and determination.",
  "Wired Fuse": "Fuse with commitment issues. Can't decide when to blow.",
  "Paper Fuse": "The most flammable safety device ever invented. Irony at its finest.",
  "Stabilized Fuse": "Finally got its act together. Reliable, dependable, boring.",
  "Improvised Screwdriver": "When you need to screw things up... I mean, fix things.",
  "Bolted Wrench": "Wrench that's really committed to the job. Bolted down for life.",
  "Combo Tool": "Swiss Army knife's overachieving cousin. Does everything, masters nothing.",
  "Repaired Pipe": "Back from the dead and ready to flow. Zombie pipe with a purpose.",
  "Heated Pipe": "Warm, cozy, and ready to deliver hot water or existential warmth.",
  "Thermo Coil": "Temperature control freak. Hot, cold, or just right - it's got you covered.",
  "Cryo Coil": "Ice cold and proud of it. Gives everyone the cold shoulder.",
  "Power Coupler": "Brings things together with electrical enthusiasm.",
  "Cryo Coupler": "Connects things while keeping them cool. The ice king of connections.",
  "Arc Cell": "Electrical storage with a sparky personality. Charges ahead with confidence.",
  "Portal Key Alpha": "First half of interdimensional access. Comes with existential dread.",
  "Portal Key Beta": "Second half of reality-bending power. Assembly required.",
  "Portal Access Token": "Your ticket to anywhere but here. Terms and conditions apply.",
  "Boss Key (Heat)": "Unlocks fiery confrontations. Warning: contents may be explosive.",
  "Boss Key (Cold)": "Opens icy encounters. Side effects include brain freeze.",
  "Boss Sigil": "The ultimate key. Opens doors you didn't know existed.",
  
  // Enemies
  "Unstable Goo": "Angry green blob with commitment issues. Dissolves everything it touches.",
  "Enemy: Voltaic Wisp": "Electrical ghost with a shocking personality. Sparks flywhen it's around.",
  "Enemy: Ooze Fish": "Aquatic nightmare fuel. Swims in goo, dreams of cleaner waters.",
  "Enemy: Crawling Sandwich": "Your lunch has gained sentience and it's not happy about being eaten.",
  "Enemy: Pipe Serpent": "Snake made of plumbing. Hisses in hydraulic and bites with water pressure.",
  "Enemy: Portal Slime": "Interdimensional goo with travel experience. Seen things, absorbed things.",
  "Enemy: Lint Golem": "Dryer lint achieved consciousness. Fluffy but deadly.",
  
  // Hazards
  "Hazard: Shocking Puddle": "Water and electricity's dangerous dance. Step carefully or get zapped.",
  "Hazard: Short Circuit": "When wires and coolant have a disagreement. Sparks will fly.",
  "Hazard: Corrosive Bristles": "Brush gone bad. Cleans by dissolving everything in its path.",
  "Soggy Paper (Hazard: Slippery)": "Wet toilet paper's revenge. Makes everything slippery and sad.",
  
  // Advanced items
  "Coolant Bowl": "Goldfish bowl filled with coolant. Fish not included, thankfully.",
  "Misting Fan": "Creates a refreshing mist while spinning. Spa day in mechanical form.",
  "Ion Sprayer": "Shoots ions with precision. Negative attitudes not welcome.",
  "Laser Duck": "Rubber duck with laser vision. Quacks and zaps with equal enthusiasm.",
  "Steam Burst": "Concentrated steam with anger management issues. Blows off steam literally.",
  "Quack of Doom": "The ultimate rubber duck weapon. Quacks of mass destruction.",
  "Cold Vent": "Blows cold air with the intensity of a disappointed parent.",
  "Cryo Foam Cannon": "Shoots freezing foam. Makes everything cold and foamy.",
  "Containment Spear": "Pointy stick for containing things. Sharp end goes toward the problem.",
  "Containment Set": "Complete containment solution. Some assembly required.",
  "Maintenance Halberd": "Medieval weapon meets modern maintenance. Fixes things with style.",
  "Stun Lance": "Pointy stick with electrical attitude. Pokes and shocks simultaneously.",
  "Air Zap Trap": "Traps air and zaps things. Multitasking at its finest.",
  "Static Sock Trap": "Sock with electrical ambitions. Clings and shocks.",
  "Stasis Snare": "Freezes things in time and space. Temporal timeout device.",
  "Ionic Towel (Defense: zap)": "Towel with electrical defense mechanisms. Dries and defends.",
  "Chill Towel (Defense: slow)": "Towel that keeps things cool under pressure. Literally.",
  "Static Bubble Duck": "Rubber duck in an electrical bubble. Protected and shocking.",
  "Bubbly Breaker": "Breaks things with the power of bubbles. Surprisingly effective.",
  "Bubble Cyclone": "Tornado made of soap bubbles. Clean destruction at its finest.",
  "Confetti Storm": "Celebration meets chaos. Party cleanup nightmare.",
  "Foam Roll": "Toilet paper's foamy evolution. Soft, absorbent, and bubbly.",
  "Foam Blaster": "Shoots foam with the enthusiasm of a caffeinated barista.",
  "Chilled Sock (Throwable)": "Cold sock with projectile potential. Chills enemies to the bone.",
  "Coolant Spill": "Accidental coolant everywhere. Slippery when wet, cold when dry.",
  "Sock Puppet Duck": "Rubber duck wearing a sock. Fashion meets function meets confusion."
};

export class ItemManager {
  private assetManager: AssetManager;
  private scene: Phaser.Scene;
  private hoverTooltip?: Phaser.GameObjects.Container;
  private tooltipBackground?: Phaser.GameObjects.Graphics;
  private tooltipText?: Phaser.GameObjects.Text;

  constructor(scene: Phaser.Scene) {
    this.scene = scene;
    this.assetManager = new AssetManager(scene);
    // Load all assets when ItemManager is created
    this.assetManager.loadAllAssets();
    this.createTooltip();
  }

  private createTooltip() {
    // Create tooltip container
    this.hoverTooltip = this.scene.add.container(0, 0);
    this.hoverTooltip.setDepth(5000); // Very high depth to stay on top
    this.hoverTooltip.setVisible(false);
    
    // Create tooltip background
    this.tooltipBackground = this.scene.add.graphics();
    this.hoverTooltip.add(this.tooltipBackground);
    
    // Create tooltip text
    this.tooltipText = this.scene.add.text(0, 0, '', {
      fontSize: '14px',
      color: '#ffffff',
      padding: { x: 12, y: 8 },
      lineSpacing: 4,
      wordWrap: { width: 300 }
    });
    this.hoverTooltip.add(this.tooltipText);
  }

  private setupItemHover(item: LabeledRect) {
    if (!item.itemName) return;

    // Make item interactive for hover
    item.setInteractive();
    
    item.on('pointerover', () => {
      item.__isHovering = true;
      
      // Start 2-second timer for tooltip
      item.__hoverTimer = this.scene.time.delayedCall(2000, () => {
        if (item.__isHovering && item.active) {
          this.showItemTooltip(item);
        }
      });
    });

    item.on('pointerout', () => {
      item.__isHovering = false;
      
      // Cancel hover timer
      if (item.__hoverTimer) {
        item.__hoverTimer.destroy();
        item.__hoverTimer = undefined;
      }
      
      // Hide tooltip
      this.hideTooltip();
    });

    item.on('pointermove', (pointer: Phaser.Input.Pointer) => {
      // Update tooltip position if it's visible
      if (this.hoverTooltip && this.hoverTooltip.visible) {
        this.updateTooltipPosition(pointer.x, pointer.y);
      }
    });
  }

  private showItemTooltip(item: LabeledRect) {
    if (!item.itemName || !this.hoverTooltip || !this.tooltipText || !this.tooltipBackground) return;

    const itemName = item.itemName;
    const description = ITEM_DESCRIPTIONS[itemName] || "A mysterious item with unknown properties.";
    
    // Get discovered merges from bestiary
    const discoveredMerges = this.getDiscoveredMergesForItem(itemName);
    
    // Build tooltip content
    let content = `${itemName}\n\n${description}`;
    
    if (discoveredMerges.length > 0) {
      content += `\n\nKnown Merges:`;
      discoveredMerges.forEach(merge => {
        content += `\n• ${merge.partner} → ${merge.result}`;
      });
    } else {
      content += `\n\nMerges: Unknown (try experimenting!)`;
    }

    this.tooltipText.setText(content);

    // Update background size
    const textBounds = this.tooltipText.getBounds();
    this.tooltipBackground.clear();
    this.tooltipBackground.fillStyle(0x2c3e50, 0.95);
    this.tooltipBackground.lineStyle(2, 0x3498db);
    this.tooltipBackground.fillRoundedRect(-12, -8, textBounds.width + 24, textBounds.height + 16, 8);
    this.tooltipBackground.strokeRoundedRect(-12, -8, textBounds.width + 24, textBounds.height + 16, 8);

    // Position tooltip near item but keep it on screen
    this.updateTooltipPosition(item.x, item.y);
    
    // Show tooltip with fade-in animation
    this.hoverTooltip.setAlpha(0);
    this.hoverTooltip.setVisible(true);
    
    this.scene.tweens.add({
      targets: this.hoverTooltip,
      alpha: 1,
      duration: 200,
      ease: 'Power2.easeOut'
    });
  }

  private updateTooltipPosition(x: number, y: number) {
    if (!this.hoverTooltip || !this.tooltipText) return;

    const textBounds = this.tooltipText.getBounds();
    const gameWidth = this.scene.scale.width;
    const gameHeight = this.scene.scale.height;
    
    // Default position: above and to the right of the cursor/item
    let tooltipX = x + 20;
    let tooltipY = y - textBounds.height - 20;
    
    // Keep tooltip on screen
    if (tooltipX + textBounds.width + 24 > gameWidth) {
      tooltipX = x - textBounds.width - 44; // Position to the left
    }
    if (tooltipY < 0) {
      tooltipY = y + 40; // Position below
    }
    if (tooltipY + textBounds.height + 16 > gameHeight) {
      tooltipY = gameHeight - textBounds.height - 32; // Keep at bottom
    }
    
    this.hoverTooltip.setPosition(tooltipX, tooltipY);
  }

  private hideTooltip() {
    if (!this.hoverTooltip) return;
    
    if (this.hoverTooltip.visible) {
      this.scene.tweens.add({
        targets: this.hoverTooltip,
        alpha: 0,
        duration: 150,
        ease: 'Power2.easeIn',
        onComplete: () => {
          this.hoverTooltip!.setVisible(false);
        }
      });
    }
  }

  private getDiscoveredMergesForItem(itemName: string): Array<{partner: string, result: string}> {
    const merges: Array<{partner: string, result: string}> = [];
    
    // Get bestiary discoveries from localStorage
    const saved = localStorage.getItem('bestiary_discoveries');
    if (!saved) return merges;
    
    try {
      const discoveries = JSON.parse(saved);
      
      // Look through discovered recipes for ones involving this item
      discoveries.forEach((discovery: any) => {
        // Parse the recipe format: "ItemA+ItemB → Result"
        const recipeParts = discovery.recipe.split(' → ');
        if (recipeParts.length !== 2) return; // Skip malformed recipes
        
        const [ingredients, result] = recipeParts;
        const ingredientParts = ingredients.split('+');
        if (ingredientParts.length !== 2) return; // Skip malformed ingredients
        
        const [itemA, itemB] = ingredientParts;
        
        // Check if this item is involved in the discovered recipe
        if (itemA === itemName) {
          merges.push({ partner: itemB, result: result });
        } else if (itemB === itemName) {
          merges.push({ partner: itemA, result: result });
        }
      });
    } catch (e) {
      console.warn('Failed to parse bestiary discoveries:', e);
    }
    
    return merges;
  }

  spawn(name: Item, x: number, y: number, color = 0x999999): LabeledRect {
    let mainObject: LabeledRect;

    // Try to create a sprite if we have an asset for this item
    const sprite = this.assetManager.createSprite(name, x, y);
    
    if (sprite) {
      // Use the sprite as the main object
      mainObject = sprite as LabeledRect;
      mainObject.setInteractive({ draggable: true });
      this.scene.input.setDraggable(mainObject);
    } else {
      // Fall back to colored rectangle - but also try to load the asset asynchronously for future spawns
      const rect = this.scene.add.rectangle(x, y, 36, 36, color) as LabeledRect;
      rect.setStrokeStyle(1, 0x222222);
      mainObject = rect;
      mainObject.setInteractive({ draggable: true });
      this.scene.input.setDraggable(mainObject);
      
      // Try to load the asset asynchronously for future spawns
      this.assetManager.loadAsset(name).then((loaded) => {
        if (loaded) {
          console.log(`Asset for ${name} loaded for future spawns`);
        }
      });
    }

    // Add physics to the main object
    this.scene.physics.add.existing(mainObject);
    mainObject.itemName = name;

    // Setup hover tooltip for all items (except enemies)
    if (!name.startsWith("Enemy:")) {
      this.setupItemHover(mainObject);
    }

    // Special behavior for Unstable Goo - make it an enemy
    if (name === "Unstable Goo") {
      this.setupUnstableGooEnemy(mainObject);
    } else {
      // Normal item behavior - draggable
      // Set up drag events
      mainObject.on(Phaser.Input.Events.DRAG, (_p: any, dx: number, dy: number) => {
        mainObject.setPosition(dx, dy);
        
        // Hide tooltip while dragging
        this.hideTooltip();
        
        // Check for mop cleaning splatters during drag
        if (name === "Mop") {
          this.checkMopSplatterCleaning(mainObject);
        }
      });
      
      mainObject.on(Phaser.Input.Events.DRAG_START, () => {
        mainObject.setDepth(1000);
        
        // Hide tooltip when dragging starts
        this.hideTooltip();
        mainObject.__isHovering = false;
        if (mainObject.__hoverTimer) {
          mainObject.__hoverTimer.destroy();
          mainObject.__hoverTimer = undefined;
        }
        
        // Rotate item to normal facing (0 degrees) when picked up
        this.scene.tweens.add({
          targets: mainObject,
          angle: 0, // Face normal/upward orientation
          duration: 200,
          ease: 'Power2.easeOut'
        });
      });
      
      mainObject.on(Phaser.Input.Events.DRAG_END, () => mainObject.setDepth(0));
    }

    // Store original scale values before animation
    const originalScaleX = mainObject.scaleX;
    const originalScaleY = mainObject.scaleY;

    // For the main object, do a subtle bounce animation that respects its current scale
    this.scene.tweens.add({
      targets: mainObject,
      scaleX: originalScaleX * 1.05, // Small bounce relative to current scale
      scaleY: originalScaleY * 1.05,
      duration: 120,
      yoyo: true,
    });

    return mainObject;
  }

  private checkMopSplatterCleaning(mop: LabeledRect) {
    // Get all goo splatters in the scene
    const gooSplatters = (this.scene as any).gooSplatters || [];
    
    gooSplatters.forEach((splatter: Phaser.GameObjects.Sprite) => {
      if (!splatter.active) return;
      
      // Check if mop is overlapping with splatter
      const mopBounds = mop.getBounds();
      const splatterBounds = splatter.getBounds();
      
      if (Phaser.Geom.Rectangle.Overlaps(mopBounds, splatterBounds)) {
        // Check if this splatter was recently cleaned (prevent rapid cleaning)
        const currentTime = this.scene.time.now;
        const lastCleanTime = (splatter as any).lastCleanTime || 0;
        
        if (currentTime - lastCleanTime > 500) { // 500ms cooldown between cleans
          this.cleanSplatter(splatter);
          (splatter as any).lastCleanTime = currentTime;
        }
      }
    });
  }

  private cleanSplatter(splatter: Phaser.GameObjects.Sprite) {
    // Increment cleanup count
    (splatter as any).cleanupCount = ((splatter as any).cleanupCount || 0) + 1;
    
    // Calculate new alpha (reduce by 25% each time)
    const originalAlpha = (splatter as any).originalAlpha || 0.8;
    const cleanupCount = (splatter as any).cleanupCount;
    const maxCleanups = (splatter as any).maxCleanups || 3;
    
    if (cleanupCount >= maxCleanups) {
      // Remove splatter completely after 3rd swipe
      this.removeSplatter(splatter);
    } else {
      // Reduce opacity by 25%
      const newAlpha = originalAlpha * (1 - (cleanupCount * 0.25));
      
      // Animate the cleaning effect
      this.scene.tweens.add({
        targets: splatter,
        alpha: newAlpha,
        scaleX: splatter.scaleX * 0.95, // Slightly shrink
        scaleY: splatter.scaleY * 0.95,
        duration: 200,
        ease: 'Power2.easeOut',
        onComplete: () => {
          // Add sparkle effect to show cleaning
          this.createCleaningSparkle(splatter.x, splatter.y);
        }
      });
    }
  }

  private removeSplatter(splatter: Phaser.GameObjects.Sprite) {
    // Create final cleaning effect
    this.createCleaningSparkle(splatter.x, splatter.y);
    
    // Animate removal
    this.scene.tweens.add({
      targets: splatter,
      alpha: 0,
      scaleX: 0,
      scaleY: 0,
      duration: 300,
      ease: 'Power2.easeIn',
      onComplete: () => {
        // Remove from splatters array
        const gooSplatters = (this.scene as any).gooSplatters || [];
        const index = gooSplatters.indexOf(splatter);
        if (index > -1) {
          gooSplatters.splice(index, 1);
        }
        
        // Destroy the splatter
        splatter.destroy();
      }
    });
  }

  private createCleaningSparkle(x: number, y: number) {
    // Create small sparkle particles to show cleaning effect
    const sparkleCount = 3;
    
    for (let i = 0; i < sparkleCount; i++) {
      // Create a small white circle as sparkle
      const sparkle = this.scene.add.circle(
        x + Phaser.Math.Between(-20, 20),
        y + Phaser.Math.Between(-20, 20),
        3,
        0xffffff
      );
      
      sparkle.setDepth(100); // Above most objects
      
      // Animate sparkle
      this.scene.tweens.add({
        targets: sparkle,
        alpha: 0,
        scaleX: 2,
        scaleY: 2,
        y: sparkle.y - 20, // Float upward
        duration: 500,
        ease: 'Power2.easeOut',
        delay: i * 100, // Stagger sparkles
        onComplete: () => {
          sparkle.destroy();
        }
      });
    }
  }

  private setupUnstableGooEnemy(goo: LabeledRect) {
    // Make Unstable Goo interactive for clicking (but not draggable)
    goo.setInteractive();
    
    // Set up physics body for movement
    const body = goo.body as Phaser.Physics.Arcade.Body;
    body.setCollideWorldBounds(true);
    body.setBounce(0.2, 0.2);
    
    // Add custom properties for enemy behavior
    (goo as any).isUnstableGoo = true;
    (goo as any).targetAsset = null;
    (goo as any).isDissolving = false;
    (goo as any).dissolveTimer = null;
    (goo as any).moveSpeed = 30; // Slow movement speed
    (goo as any).hasLanded = false;
    
    // Add health system properties
    (goo as any).maxHealth = Phaser.Math.Between(1, 10); // Random health between 1-10
    (goo as any).currentHealth = (goo as any).maxHealth;
    (goo as any).isStopped = false;
    (goo as any).stopTimer = null;
    
    // Add click handler for damaging the goo
    goo.on('pointerdown', () => {
      this.damageGoo(goo);
    });
    
    // Wait for goo to land before starting AI behavior
    this.scene.time.delayedCall(2000, () => {
      (goo as any).hasLanded = true;
      this.correctGooFacing(goo);
      this.startGooAI(goo);
    });
  }

  private damageGoo(goo: LabeledRect) {
    if (!goo.active || (goo as any).isDissolving) return;
    
    // Reduce health
    (goo as any).currentHealth--;
    
    // Visual feedback - flash red and scale slightly
    this.scene.tweens.add({
      targets: goo,
      tint: 0xff4444, // Red flash
      scaleX: goo.scaleX * 1.2,
      scaleY: goo.scaleY * 1.2,
      duration: 100,
      yoyo: true,
      onComplete: () => {
        goo.setTint(0xffffff); // Reset tint
      }
    });
    
    // Stop the goo for 0.25 seconds
    this.stopGoo(goo, 250); // 250ms = 0.25 seconds
    
    // Check if goo is destroyed
    if ((goo as any).currentHealth <= 0) {
      this.destroyGoo(goo);
    }
  }

  private stopGoo(goo: LabeledRect, duration: number) {
    if (!goo.active) return;
    
    // Mark as stopped
    (goo as any).isStopped = true;
    
    // Stop movement
    const body = goo.body as Phaser.Physics.Arcade.Body;
    body.setVelocity(0, 0);
    
    // Clear existing stop timer if any
    if ((goo as any).stopTimer) {
      (goo as any).stopTimer.destroy();
    }
    
    // Set timer to resume movement
    (goo as any).stopTimer = this.scene.time.delayedCall(duration, () => {
      if (goo.active && !(goo as any).isDissolving) {
        (goo as any).isStopped = false;
        (goo as any).stopTimer = null;
        
        // Resume AI if goo has landed
        if ((goo as any).hasLanded) {
          this.resumeGooMovement(goo);
        }
      }
    });
  }

  private resumeGooMovement(goo: LabeledRect) {
    if (!goo.active || (goo as any).isDissolving || (goo as any).isStopped) return;
    
    // Find target and resume movement
    const target = (goo as any).targetAsset || this.findNearestAsset(goo);
    if (target && target.active) {
      (goo as any).targetAsset = target;
      this.moveGooTowardTarget(goo, target);
    }
  }

  private destroyGoo(goo: LabeledRect) {
    // Stop all timers and movement
    (goo as any).isStopped = true;
    (goo as any).isDissolving = true;
    
    if ((goo as any).stopTimer) {
      (goo as any).stopTimer.destroy();
    }
    
    if ((goo as any).dissolveTimer) {
      (goo as any).dissolveTimer.destroy();
    }
    
    // Stop movement
    const body = goo.body as Phaser.Physics.Arcade.Body;
    body.setVelocity(0, 0);
    
    // Create splatter decal at goo's position before destroying it
    this.createGooSplatter(goo.x, goo.y, goo.scaleX);
    
    // Death animation - shrink and fade
    this.scene.tweens.add({
      targets: goo,
      scaleX: 0,
      scaleY: 0,
      alpha: 0,
      angle: goo.angle + 180, // Spin while shrinking
      duration: 500,
      ease: 'Power2.easeIn',
      onComplete: () => {
        this.destroy(goo);
      }
    });
    
    // Visual effect - green particles or flash to indicate successful destruction
    this.scene.tweens.add({
      targets: goo,
      tint: 0x44ff44, // Green flash
      duration: 100,
      yoyo: true,
      repeat: 2
    });
  }

  private createGooSplatter(x: number, y: number, gooScale: number) {
    // Create a permanent splatter sprite at the goo's death location
    const splatter = this.scene.add.sprite(x, y, 'goo_splatter');
    
    // Set splatter size to exactly 125% of the originating goo's size
    const splatterScale = gooScale * 1.25; // 125% of the goo's scale
    splatter.setScale(splatterScale);
    
    // Set low depth so it appears behind other game objects
    splatter.setDepth(-10);
    
    // Add limited random rotation - only ±15 degrees
    const maxRotationDegrees = 15;
    const randomRotationDegrees = Phaser.Math.Between(-maxRotationDegrees, maxRotationDegrees);
    splatter.setRotation(randomRotationDegrees * Math.PI / 180);
    
    // Add splatter cleanup properties
    (splatter as any).cleanupCount = 0; // Track how many times it's been mopped
    (splatter as any).maxCleanups = 3; // Remove after 3 mops
    (splatter as any).originalAlpha = 0.8; // Store original alpha
    
    // Optional: Add a subtle fade-in animation
    splatter.setAlpha(0);
    this.scene.tweens.add({
      targets: splatter,
      alpha: (splatter as any).originalAlpha,
      duration: 300,
      ease: 'Power2.easeOut'
    });
    
    // Store splatter reference if we need to clean them up later
    if (!(this.scene as any).gooSplatters) {
      (this.scene as any).gooSplatters = [];
    }
    (this.scene as any).gooSplatters.push(splatter);
  }

  private correctGooFacing(goo: LabeledRect) {
    // Correct the goo's rotation to be upright (0 degrees)
    this.scene.tweens.add({
      targets: goo,
      angle: 0,
      duration: 500,
      ease: 'Power2.easeOut'
    });
  }

  private findNearestAsset(goo: LabeledRect): LabeledRect | null {
    let nearestAsset: LabeledRect | null = null;
    let nearestDistance = Infinity;
    
    // Get all items in the scene that are not Unstable Goo
    this.scene.children.list.forEach(child => {
      if ((child as any).itemName && 
          (child as any).itemName !== "Unstable Goo" && 
          !(child as any).isUnstableGoo &&
          child.active) {
        
        const distance = Phaser.Math.Distance.Between(
          goo.x, goo.y,
          child.x, child.y
        );
        
        if (distance < nearestDistance) {
          nearestDistance = distance;
          nearestAsset = child as LabeledRect;
        }
      }
    });
    
    return nearestAsset;
  }

  private moveGooTowardTarget(goo: LabeledRect, target: LabeledRect) {
    if (!goo.active || !target.active || (goo as any).isDissolving || (goo as any).isStopped) return;
    
    const body = goo.body as Phaser.Physics.Arcade.Body;
    const moveSpeed = (goo as any).moveSpeed;
    
    // Calculate direction to target
    const angle = Phaser.Math.Angle.Between(goo.x, goo.y, target.x, target.y);
    
    // Set velocity toward target
    body.setVelocity(
      Math.cos(angle) * moveSpeed,
      Math.sin(angle) * moveSpeed
    );
  }

  private startGooAI(goo: LabeledRect) {
    if (!goo.active || (goo as any).isDissolving) return;
    
    // Find the nearest asset to target
    const nearestAsset = this.findNearestAsset(goo);
    (goo as any).targetAsset = nearestAsset;
    
    // Start movement toward target (only if not stopped)
    if (nearestAsset && !(goo as any).isStopped) {
      this.moveGooTowardTarget(goo, nearestAsset);
    }
    
    // Set up overlap detection with all assets
    this.setupGooOverlapDetection(goo);
    
    // Repeat AI update every 2 seconds
    this.scene.time.delayedCall(2000, () => {
      this.startGooAI(goo);
    });
  }

  private setupGooOverlapDetection(goo: LabeledRect) {
    if (!goo.active || (goo as any).isDissolving) return;
    
    // Check for overlaps with assets every frame
    const overlapCheck = () => {
      if (!goo.active || (goo as any).isDissolving) return;
      
      // Get all items in the scene that are not Unstable Goo
      this.scene.children.list.forEach(child => {
        if ((child as any).itemName && 
            (child as any).itemName !== "Unstable Goo" && 
            !(child as any).isUnstableGoo &&
            child.active) {
          
          const asset = child as LabeledRect;
          
          // Check if goo is fully overlapping the asset
          if (this.isFullyOverlapping(goo, asset)) {
            this.startDissolveProcess(goo, asset);
            return; // Exit loop once we start dissolving
          }
        }
      });
      
      // Continue checking if not dissolving
      if (goo.active && !(goo as any).isDissolving) {
        this.scene.time.delayedCall(100, overlapCheck);
      }
    };
    
    // Start overlap checking
    overlapCheck();
  }

  private isFullyOverlapping(goo: LabeledRect, asset: LabeledRect): boolean {
    const gooBounds = goo.getBounds();
    const assetBounds = asset.getBounds();
    
    // Calculate the intersection area
    const intersectionLeft = Math.max(gooBounds.left, assetBounds.left);
    const intersectionRight = Math.min(gooBounds.right, assetBounds.right);
    const intersectionTop = Math.max(gooBounds.top, assetBounds.top);
    const intersectionBottom = Math.min(gooBounds.bottom, assetBounds.bottom);
    
    // Check if there's any intersection at all
    if (intersectionLeft >= intersectionRight || intersectionTop >= intersectionBottom) {
      return false; // No intersection
    }
    
    // Calculate intersection area
    const intersectionWidth = intersectionRight - intersectionLeft;
    const intersectionHeight = intersectionBottom - intersectionTop;
    const intersectionArea = intersectionWidth * intersectionHeight;
    
    // Calculate asset area
    const assetWidth = assetBounds.right - assetBounds.left;
    const assetHeight = assetBounds.bottom - assetBounds.top;
    const assetArea = assetWidth * assetHeight;
    
    // Check if at least 25% of the asset is overlapped
    const overlapPercentage = intersectionArea / assetArea;
    return overlapPercentage >= 0.25; // 25% overlap threshold
  }

  private completeDissolveProcess(goo: LabeledRect, asset: LabeledRect) {
    if (!goo.active || !asset.active) return;
    
    // Destroy the asset
    this.destroy(asset);
    
    // Grow the goo by 25% (cumulative growth)
    const newScaleX = goo.scaleX * 1.25;
    const newScaleY = goo.scaleY * 1.25;
    
    this.scene.tweens.add({
      targets: goo,
      scaleX: newScaleX,
      scaleY: newScaleY,
      duration: 500,
      ease: 'Power2.easeOut',
      onComplete: () => {
        // Reset goo state and resume AI - but DON'T reset scale
        (goo as any).isDissolving = false;
        (goo as any).dissolveTimer = null;
        (goo as any).targetAsset = null;
        
        // Resume AI behavior after a short delay
        this.scene.time.delayedCall(1000, () => {
          this.startGooAI(goo);
        });
      }
    });
    
    // Visual effect for successful dissolve
    this.scene.tweens.add({
      targets: goo,
      tint: 0x44ff44, // Green flash
      duration: 200,
      yoyo: true,
      onComplete: () => {
        goo.setTint(0xffffff); // Reset to normal color
      }
    });
  }

  private startDissolveProcess(goo: LabeledRect, asset: LabeledRect) {
    if ((goo as any).isDissolving || (goo as any).isStopped) return; // Don't start dissolving if stopped
    
    (goo as any).isDissolving = true;
    
    // Stop goo movement
    const body = goo.body as Phaser.Physics.Arcade.Body;
    body.setVelocity(0, 0);
    
    // Visual feedback - make asset flash red and fade
    this.scene.tweens.add({
      targets: asset,
      tint: 0xff4444,
      alpha: 0.5,
      duration: 200,
      yoyo: true,
      repeat: -1 // Repeat until dissolve completes
    });
    
    // Start 3-second dissolve timer
    (goo as any).dissolveTimer = this.scene.time.delayedCall(3000, () => {
      this.completeDissolveProcess(goo, asset);
    });
    
    // Visual feedback for goo - pulsing effect during dissolve (relative to current size)
    const currentScaleX = goo.scaleX;
    const currentScaleY = goo.scaleY;
    
    this.scene.tweens.add({
      targets: goo,
      scaleX: currentScaleX * 1.1, // Pulse relative to current size
      scaleY: currentScaleY * 1.1,
      duration: 300,
      yoyo: true,
      repeat: 9, // Pulse for 3 seconds (300ms * 2 * 10 = 6 seconds total, but timer will stop it)
      onComplete: () => {
        // Ensure goo returns to its current size (not original size)
        goo.setScale(currentScaleX, currentScaleY);
      }
    });
  }

  private rejectItem(obj: LabeledRect) {
    // Animate item bouncing out of toilet
    const bounceDistance = 100;
    const bounceAngle = Phaser.Math.Between(-45, 45); // Random angle between -45 and 45 degrees
    const bounceRad = Phaser.Math.DegToRad(bounceAngle);
    
    const bounceX = obj.x + Math.cos(bounceRad) * bounceDistance;
    const bounceY = obj.y + Math.sin(bounceRad) * bounceDistance;
    
    // Animate bounce out
    this.scene.tweens.add({
      targets: obj,
      x: bounceX,
      y: bounceY,
      duration: 300,
      ease: 'Power2.easeOut',
      onComplete: () => {
        // Then settle to a nearby position
        const settleX = bounceX + Phaser.Math.Between(-20, 20);
        const settleY = Math.max(bounceY + 50, 450); // Ensure it settles on the floor
        
        this.scene.tweens.add({
          targets: obj,
          x: settleX,
          y: settleY,
          duration: 200,
          ease: 'Power2.easeIn'
        });
      }
    });
    
    // Add visual feedback - red tint to show rejection
    this.scene.tweens.add({
      targets: obj,
      tint: 0xff4444, // Red tint
      duration: 150,
      yoyo: true,
      repeat: 2,
      onComplete: () => {
        obj.setTint(0xffffff); // Reset to normal color
      }
    });
  }

  destroy(obj: LabeledRect) {
    // Clean up hover timer and tooltip
    if (obj.__hoverTimer) {
      obj.__hoverTimer.destroy();
    }
    if (obj.__isHovering) {
      this.hideTooltip();
    }
    
    // Emit destroy event before actually destroying
    obj.emit('destroy');
    // Remove label destruction since there are no labels
    // obj.__label?.destroy();
    obj.__visualSprite?.destroy(); // Clean up visual sprite if it exists
    obj.destroy();
  }

  // Method to get the asset manager for external use
  getAssetManager(): AssetManager {
    return this.assetManager;
  }
}

export class PortalSpawner {
  private timer?: Phaser.Time.TimerEvent;
  private portalViz?: Phaser.GameObjects.Ellipse;
  private mouth: Phaser.Math.Vector2 = new Phaser.Math.Vector2();
  private spawnedItems: Set<LabeledRect> = new Set(); // Track spawned items
  private mergedResults: Set<Item> = new Set(); // Track items that have been merged
  private hasInitialSpawn: boolean = false; // Track if we've done initial spawn

  constructor(
    private scene: Phaser.Scene,
    private items: ItemManager,
    private portalSprite: Phaser.GameObjects.Sprite
  ) {
    // Initialize mouth position immediately
    this.initMouth();
    
    // Listen for penalty events to spawn Unstable Goo
    this.scene.events.on("toilet:penalty", (penaltyItem: string) => {
      this.spawnPenaltyItem(penaltyItem);
    });
  }

  start(intervalMs = 3000) { // Keep interval parameter for potential future use
    this.stop();

    this.initMouth();
    
    // Remove automatic spawning - items now only come from successful merges
    // No timer needed since we only spawn on toilet:merged events
    
    // Remove the timer creation since we don't want automatic spawning
    // this.timer = this.scene.time.addEvent({
    //   delay: intervalMs,
    //   loop: true,
    //   callback: () => this.maintainItemCount(),
    // });
  }

  stop() {
    this.timer?.remove();
    this.timer = undefined;
    this.portalViz?.destroy();
    this.spawnedItems.clear();
  }

  // Method to add a merged result to our spawnable pool
  public addMergedResult(resultItem: Item) {
    this.mergedResults.add(resultItem);
  }

  private initMouth() {
    // Use the portal sprite's position for spawning
    const x = this.portalSprite.x;
    const y = this.portalSprite.y + 50; // Slightly below the portal sprite
    this.mouth.set(x, y);
    console.log(`Portal mouth initialized at: ${x}, ${y}`);
  }

  private cleanupDestroyedItems() {
    // Remove items that have been destroyed from our tracking set
    const itemsToRemove: LabeledRect[] = [];
    
    this.spawnedItems.forEach(item => {
      if (!item.active || item.scene !== this.scene) {
        itemsToRemove.push(item);
      }
    });
    
    itemsToRemove.forEach(item => {
      this.spawnedItems.delete(item);
    });
  }

  private getRandomMergedResult(): Item | null {
    if (this.mergedResults.size === 0) {
      return null;
    }
    
    const mergedArray = Array.from(this.mergedResults);
    return mergedArray[Math.floor(Math.random() * mergedArray.length)];
  }

  private dropSpecificItem(itemName: Item) {
    // Only allow merged results - no more tier 1 items from portal
    if (!this.mergedResults.has(itemName)) {
      return;
    }
    
    // Spawn at portal mouth with slight random offset
    const x = this.mouth.x + Phaser.Math.Between(-30, 30);
    const y = this.mouth.y;

    const obj = this.items.spawn(itemName, x, y, 0x8888ff);
    
    // Track this spawned item
    this.spawnedItems.add(obj);
    
    // Listen for when this item is destroyed (merged)
    obj.once('destroy', () => {
      this.spawnedItems.delete(obj);
    });

    // Use the portal sprite for visual feedback
    if (this.portalSprite) {
      this.scene.tweens.add({
        targets: this.portalSprite,
        scaleX: 1.15,
        scaleY: 1.15,
        duration: 140,
        yoyo: true,
      });
    }

    // Find a random landing spot that doesn't overlap with existing items
    const landingSpot = this.findRandomLandingSpot();
    
    // Create a bouncing trajectory to the landing spot
    this.createBouncingTrajectory(obj, landingSpot.x, landingSpot.y);
  }

  public spawnAtPortal(name: string) {
    console.log(`Spawning ${name} at portal mouth: ${this.mouth.x}, ${this.mouth.y}`);
    
    // Add this result to our merged results pool for future reference
    this.addMergedResult(name);
    
    // Spawn exactly 1 item as reward for successful merge
    const obj = this.items.spawn(name, this.mouth.x, this.mouth.y, 0x55aa55);
    
    // Don't track this item in spawnedItems since we're not maintaining a count anymore
    // These are rewards, not part of any item limit
    
    // Find a random landing spot that doesn't overlap with existing items
    const landingSpot = this.findRandomLandingSpot();
    
    // Create a bouncing trajectory to the landing spot
    this.createBouncingTrajectory(obj, landingSpot.x, landingSpot.y);
    
    // Use the portal sprite for visual feedback
    if (this.portalSprite) {
      this.scene.tweens.add({ targets: this.portalSprite, scaleX: 1.2, scaleY: 1.2, duration: 140, yoyo: true });
    }
  }

  private findRandomLandingSpot(): { x: number, y: number } {
    const floorY = 473 - 18; // Top of Floor Platform minus half item height
    const minX = 100; // Left boundary with some margin
    const maxX = 1000; // Right boundary with some margin
    const itemSize = 36; // Item size for collision detection
    const minDistance = 50; // Minimum distance between items
    
    let attempts = 0;
    const maxAttempts = 20;
    
    while (attempts < maxAttempts) {
      const randomX = Phaser.Math.Between(minX, maxX);
      const randomY = floorY;
      
      // Check if this spot is too close to existing items
      let tooClose = false;
      
      // Get all existing items in the scene
      const existingItems = this.scene.children.list.filter(child => 
        child instanceof Phaser.GameObjects.Rectangle && 
        (child as any).itemName
      );
      
      for (const existingItem of existingItems) {
        const distance = Phaser.Math.Distance.Between(
          randomX, randomY,
          existingItem.x, existingItem.y
        );
        
        if (distance < minDistance) {
          tooClose = true;
          break;
        }
      }
      
      if (!tooClose) {
        return { x: randomX, y: randomY };
      }
      
      attempts++;
    }
    
    // If we couldn't find a good spot after max attempts, just use a random spot
    return { 
      x: Phaser.Math.Between(minX, maxX), 
      y: floorY 
    };
  }

  private createBouncingTrajectory(obj: any, targetX: number, targetY: number) {
    const startX = obj.x;
    const startY = obj.y;
    const groundY = 473 - 18; // Floor Platform top minus half item height
    
    // Calculate horizontal distance and add some randomness to the trajectory
    const horizontalDistance = targetX - startX;
    const fallTime = 500; // Slightly faster fall
    
    // Phase 1: Natural fall with slight horizontal drift - remove label from targets
    this.scene.tweens.add({
      targets: obj, // Remove obj.__label from targets
      x: startX + (horizontalDistance * 0.3), // Only move 30% during fall
      y: groundY,
      duration: fallTime,
      ease: "Power2.easeIn", // More realistic gravity curve
      onComplete: () => {
        // Phase 2: First bounce - highest - remove label from targets
        this.scene.tweens.add({
          targets: obj, // Remove obj.__label from targets
          x: startX + (horizontalDistance * 0.6), // Move more horizontally
          y: groundY - Phaser.Math.Between(20, 30), // Random bounce height
          duration: Phaser.Math.Between(180, 220), // Slight time variation
          ease: "Power2.easeOut",
          onComplete: () => {
            // Phase 3: Fall from first bounce - remove label from targets
            this.scene.tweens.add({
              targets: obj, // Remove obj.__label from targets
              x: startX + (horizontalDistance * 0.8), // Continue moving
              y: groundY,
              duration: Phaser.Math.Between(160, 200),
              ease: "Power2.easeIn",
              onComplete: () => {
                // Phase 4: Second bounce - smaller - remove label from targets
                this.scene.tweens.add({
                  targets: obj, // Remove obj.__label from targets
                  x: targetX, // Reach final position
                  y: groundY - Phaser.Math.Between(8, 15), // Smaller random bounce
                  duration: Phaser.Math.Between(120, 160),
                  ease: "Power2.easeOut",
                  onComplete: () => {
                    // Phase 5: Final settle - remove label from targets
                    this.scene.tweens.add({
                      targets: obj, // Remove obj.__label from targets
                      y: targetY,
                      duration: Phaser.Math.Between(100, 140),
                      ease: "Power2.easeIn"
                    });
                  }
                });
              }
            });
          }
        });
      }
    });
    
    // Add more natural rotation with some randomness
    const rotationAmount = Phaser.Math.Between(180, 360);
    const rotationDirection = Phaser.Math.RND.pick([-1, 1]);
    
    this.scene.tweens.add({
      targets: obj,
      angle: rotationAmount * rotationDirection,
      duration: 1200, // Total duration across all phases
      ease: "Power1.easeOut" // Rotation slows down naturally
    });
  }

  public spawnPenaltyItem(penaltyItem: string) {
    console.log(`Spawning penalty item ${penaltyItem} at portal mouth: ${this.mouth.x}, ${this.mouth.y}`);
    
    // Spawn penalty item (like Unstable Goo) from portal
    const obj = this.items.spawn(penaltyItem, this.mouth.x, this.mouth.y, 0xff4444); // Red tint for penalty
    
    // Find a random landing spot
    const landingSpot = this.findRandomLandingSpot();
    
    // Create a bouncing trajectory to the landing spot
    this.createBouncingTrajectory(obj, landingSpot.x, landingSpot.y);
    
    // Use the portal sprite for visual feedback (different color for penalty)
    if (this.portalSprite) {
      this.scene.tweens.add({ 
        targets: this.portalSprite, 
        tint: 0xff4444, // Red tint for penalty
        scaleX: 1.2, 
        scaleY: 1.2, 
        duration: 140, 
        yoyo: true,
        onComplete: () => {
          // Reset tint after animation
          this.portalSprite.setTint(0xffffff);
        }
      });
    }
  }
}

export class MergeToilet {
  private zone: Phaser.GameObjects.Zone;
  private viz: Phaser.GameObjects.Rectangle;
  private waiting: LabeledRect[] = [];
  private splashSounds: Phaser.Sound.BaseSound[] = [];
  private currentSplashIndex: number = 0;

  constructor(
    private scene: Phaser.Scene,
    private items: ItemManager,
    x: number,
    y: number,
    w = 140,
    h = 140
  ) {
    this.zone = this.scene.add.zone(x, y, w, h);
    this.scene.physics.add.existing(this.zone, true);

    this.viz = this.scene.add
      .rectangle(x, y, w, h, 0x3355aa, 0) // Changed alpha from 0.12 to 0 (invisible)
      .setStrokeStyle(0, 0x3355aa); // Changed stroke width from 2 to 0 (no border)

    // Initialize splash sounds
    this.initializeSplashSounds();

    // Accept drops that end inside the zone
    this.scene.input.on(Phaser.Input.Events.DRAG_END, (_: any, obj: any) => {
      if (!obj?.itemName) return;
      const b = this.viz.getBounds();
      if (Phaser.Geom.Rectangle.Contains(b, obj.x, obj.y)) {
        this.accept(obj);
      } else {
        // Check if item was previously in toilet and is now being dragged out
        this.checkItemRemoval(obj);
      }
    });

    // Listen for toilet flush to trigger merge
    this.scene.events.on("toilet:flush", () => this.onFlush());
  }

  private initializeSplashSounds() {
    // Create the splash sound objects with different volumes for variety
    this.splashSounds = [
      this.scene.sound.add('splash1', { volume: 0.6 }),
      this.scene.sound.add('splash2', { volume: 0.7 }),
      this.scene.sound.add('splash3', { volume: 0.65 })
    ];
  }

  private playRandomSplashSound() {
    if (this.splashSounds.length === 0) return;
    
    // Play the current splash sound
    this.splashSounds[this.currentSplashIndex].play();
    
    // Move to next sound for variety (cycle through all sounds)
    this.currentSplashIndex = (this.currentSplashIndex + 1) % this.splashSounds.length;
  }

  private checkItemRemoval(obj: LabeledRect) {
    // Check if this item was in the waiting list (meaning it was in the toilet)
    const index = this.waiting.indexOf(obj);
    if (index !== -1) {
      // Remove item from waiting list
      this.waiting.splice(index, 1);
      
      // Restore original size if we stored it
      if ((obj as any).__originalScaleX && (obj as any).__originalScaleY) {
        this.scene.tweens.add({
          targets: obj,
          scaleX: (obj as any).__originalScaleX,
          scaleY: (obj as any).__originalScaleY,
          duration: 300,
          ease: 'Power2.easeOut'
        });
        
        // Clean up stored values
        delete (obj as any).__originalScaleX;
        delete (obj as any).__originalScaleY;
      }
      
      // Remove label scale restoration since there are no labels
      // if (obj.__label) {
      //   this.scene.tweens.add({
      //     targets: obj.__label,
      //     scaleX: 1,
      //     scaleY: 1,
      //     duration: 300,
      //     ease: 'Power2.easeOut'
      //   });
      // }
    }
  }

  private accept(obj: LabeledRect) {
    if (this.waiting.includes(obj)) return;
    
    // Play splash sound when item is dropped in toilet
    this.playRandomSplashSound();
    
    // If there's already an item waiting, check if they can merge before accepting
    if (this.waiting.length === 1) {
      const existingItem = this.waiting[0];
      const result = getMergeResult(existingItem.itemName!, obj.itemName!);
      
      // If they can't merge, reject the new item and prepare for penalty spawn
      if (!result) {
        // Store the items for destruction when flushed
        this.waiting.push(obj); // Add the new item to waiting list for destruction
        
        // Position the new item in toilet like normal
        obj.x = this.zone.x + Phaser.Math.Between(-14, 14);
        obj.y = this.zone.y + Phaser.Math.Between(-10, 10);
        
        // Store original scale values before making smaller
        (obj as any).__originalScaleX = obj.scaleX;
        (obj as any).__originalScaleY = obj.scaleY;
        
        // Make item smaller when placed in toilet
        this.scene.tweens.add({
          targets: obj,
          scaleX: obj.scaleX * 0.6,
          scaleY: obj.scaleY * 0.6,
          duration: 300,
          ease: 'Power2.easeOut'
        });
        
        return; // Don't spit out immediately, wait for flush
      }
    }
    
    // Accept the item into the toilet zone (valid combination or first item)
    obj.x = this.zone.x + Phaser.Math.Between(-14, 14);
    obj.y = this.zone.y + Phaser.Math.Between(-10, 10);

    // Store original scale values before making smaller
    (obj as any).__originalScaleX = obj.scaleX;
    (obj as any).__originalScaleY = obj.scaleY;
    
    // Make item smaller when placed in toilet
    this.scene.tweens.add({
      targets: obj,
      scaleX: obj.scaleX * 0.6,
      scaleY: obj.scaleY * 0.6,
      duration: 300,
      ease: 'Power2.easeOut'
    });

    this.waiting.push(obj);
    
    // Visual feedback when items are ready to merge
    if (this.waiting.length === 2) {
      const result = getMergeResult(this.waiting[0].itemName!, this.waiting[1].itemName!);
      
      if (result) {
        // Valid combination - show ready-to-merge feedback
        this.waiting.forEach(item => {
          const currentScalex = item.scaleX;
          const currentScaleY = item.scaleY;
          
          this.scene.tweens.add({
            targets: item,
            scaleX: currentScalex * 1.1,
            scaleY: currentScaleY * 1.1,
            duration: 200,
            yoyo: true,
          });
        });
      } else {
        // Invalid combination - show warning feedback (red tint)
        this.waiting.forEach(item => {
          this.scene.tweens.add({
            targets: item,
            tint: 0xff4414, // Red tint to indicate invalid combination
            duration: 300,
            yoyo: true,
            repeat: 2
          });
        });
      }
    }
  }

  private onFlush() {
    // Only process if we have exactly 2 items
    if (this.waiting.length !== 2) return;

    const [aObj, bObj] = this.waiting.splice(0, 2);
    const a = aObj.itemName!;
    const b = bObj.itemName!;
    const result = getMergeResult(a, b);

    if (result) {
      // Valid merge - proceed normally
      this.items.destroy(aObj);
      this.items.destroy(bObj);

      // Track the merge in the bestiary
      const bestiaryScene = this.scene.scene.get('Bestiary');
      if (bestiaryScene && (bestiaryScene as any).addDiscovery) {
        (bestiaryScene as any).addDiscovery(a, b, result);
      }

      // Emit event for successful merge (this will spawn from portal)
      this.scene.events.emit("toilet:merged", result);
    } else {
      // Invalid merge - destroy items and spawn Unstable Goo as penalty
      this.scene.tweens.add({
        targets: [aObj, bObj],
        alpha: 0,
        angle: "+=15",
        duration: 180,
        onComplete: () => {
          this.items.destroy(aObj);
          this.items.destroy(bObj);
          
          // Spawn Unstable Goo from portal as penalty
          this.scene.events.emit("toilet:penalty", "Unstable Goo");
        },
      });
    }
  }

  public hasAnyItems(): boolean {
    return this.waiting.length > 0;
  }

  public hasItemsReadyToMerge(): boolean {
    return this.waiting.length === 2;
  }

  destroy() {
    this.viz.destroy();
    this.zone.destroy();
    this.waiting.length = 0;
  }
}

/** Quick wiring helper */
export function initMergeCore(
  scene: Phaser.Scene,
  portalSprite: Phaser.GameObjects.Sprite | null, // Allow null for tutorial
  toilet: { x: number; y: number; w?: number; h?: number }
) {
  scene.physics.world.setBounds(0, 0, scene.scale.width, scene.scale.height);

  const items = new ItemManager(scene);
  const toiletZone = new MergeToilet(
    scene,
    items,
    toilet.x,
    toilet.y,
    toilet.w ?? 140,
    toilet.h ?? 140
  );
  
  // Only create spawner if portal sprite is provided
  let spawner: PortalSpawner | null = null;
  if (portalSprite) {
    spawner = new PortalSpawner(scene, items, portalSprite);
  }

  // Return an object that allows spawner to be added later
  const mergeSystem = { 
    items, 
    toilet: toiletZone, 
    spawner,
    // Method to add spawner later during tutorial
    setSpawner: (newSpawner: PortalSpawner) => {
      mergeSystem.spawner = newSpawner;
    }
  };

  return mergeSystem;
}