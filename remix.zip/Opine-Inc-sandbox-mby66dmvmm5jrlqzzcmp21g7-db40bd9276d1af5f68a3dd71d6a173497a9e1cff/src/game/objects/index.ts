
// src/game/objects/index.ts

export { AssetManager } from './AssetManager'
export { BoxSpawner } from './BoxSpawner'
export { MergeItem } from './MergeItem'
export { HintButton } from './HintButton'
export { initMergeCore } from './mergeCore'