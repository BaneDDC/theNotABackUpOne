
import { Scene } from "phaser"
import { initMergeCore } from "../objects/mergeCore"
import { BoxSpawner } from "../objects/BoxSpawner"
import { HintButton } from "../objects/HintButton"

export class Game extends Scene {
  private toiletSound!: Phaser.Sound.BaseSound
  private lastToiletSoundTime: number = 0
  private readonly TOILET_SOUND_COOLDOWN = 7000 // 7 seconds in milliseconds
  private plungerSound!: Phaser.Sound.BaseSound
  private lastPlungerSoundTime: number = 0
  private readonly PLUNGER_SOUND_COOLDOWN = 5000 // 5 seconds in milliseconds
  private FlushCount: number = 0 // Start with toilet empty
  private toilet!: Phaser.GameObjects.Sprite // Reference to toilet sprite
  private plunger!: Phaser.GameObjects.Sprite // Reference to plunger sprite
  private plungerOriginalX: number = 0
  private plungerOriginalY: number = 0
  private plungerVibrateTimer!: Phaser.Time.TimerEvent // Timer for plunger vibration
  private boxSpawner!: BoxSpawner // Reference to box spawner
  private customCursor!: Phaser.GameObjects.Sprite // Global custom cursor
  private isPointerDown: boolean = false
  private hintButton!: HintButton // Reference to hint button
  private toiletPulseTween?: Phaser.Tweens.Tween // Reference to toilet pulse tween
  private tutorialPhase: boolean = true // Track if we're in tutorial phase
  private portalCreated: boolean = false // Track if portal has been created

  constructor() {
    super("Game")
  }

  preload() {
    // Assets are now loaded in Boot scene, so this method can be empty or minimal
    // Only load any assets that are specific to this scene and not global
  }

  create() {
    // Enable physics for this scene
    this.physics.world.setBounds(0, 0, 1170, 540)
    
    // Set up global custom cursor first
    this.setupGlobalCustomCursor()
    
    this.setupAnimatedBackground()
    // Don't setup portal initially - it will be created after tutorial
    this.setupNewSprite()
    this.setupToilet()
    this.setupPlunger()
    this.setupSink()
    this.setupTowel()
    this.setupToiletPaperBackground()
    
    // Create the toilet sound
    this.toiletSound = this.sound.add('toiletFlush', { volume: 0.5 })
    
    // Create the plunger sound
    this.plungerSound = this.sound.add('plungerSound', { volume: 0.7 })
    
    // Setup F9 key to launch collision editor
    this.setupCollisionEditorKey()
    
    // Set initial toilet state (empty, so no need to move plunger or start vibration)
    this.updateToiletSprite()

    // Initialize merge system (without portal initially)
    this.setupMergeSystem()

    // Create hint button
    this.setupHintButton()

    // Launch bestiary scene as overlay (always visible in corner)
    this.scene.launch('Bestiary')
    
    // Create pause menu button next to bestiary
    this.setupPauseMenuButton()
    
    // Ensure cursor stays on top after bestiary is launched
    this.time.delayedCall(100, () => {
      this.recreateCustomCursor()
    })

    // Listen for plunger mini-game results
    this.events.on('plunger:result', (result: 'green' | 'red' | 'yellow') => {
      this.handlePlungerResult(result)
    })

    // Listen for toilet pulsing events
    this.events.on('toilet:startPulsing', () => {
      this.startToiletPulsing();
    });

    // Listen for tutorial completion
    this.events.on('tutorial:complete', () => {
      this.completeTutorial();
    });
  }

  private setupPauseMenuButton() {
    // Create pause menu button next to the bestiary book
    const buttonSize = 80; // Same size as bestiary book
    const cornerPadding = 20;
    const spacing = 10; // Space between bestiary and pause button
    
    // Position to the left of the bestiary book
    const pauseButton = this.add.sprite(
      this.scale.width - cornerPadding - buttonSize - (buttonSize / 2) - spacing, // Left of bestiary
      cornerPadding + (buttonSize / 2), 
      '__WHITE' // Use white texture as placeholder
    );
    
    pauseButton.setDisplaySize(buttonSize, buttonSize);
    pauseButton.setTint(0x34495e); // Dark gray color for pause button
    pauseButton.setDepth(500); // Same depth as bestiary to stay below cursor
    pauseButton.setInteractive();
    
    // Add pause symbol (two vertical bars) as text overlay
    const pauseSymbol = this.add.text(
      pauseButton.x,
      pauseButton.y,
      '❚❚', // Pause symbol
      {
        fontSize: '32px',
        color: '#ffffff',
        fontStyle: 'bold'
      }
    );
    pauseSymbol.setOrigin(0.5);
    pauseSymbol.setDepth(501); // Above the button background
    
    // Add click handler to open pause menu
    pauseButton.on('pointerdown', () => {
      // Pause this scene and launch the pause menu
      this.scene.pause();
      this.scene.launch('PauseMenu');
    });
    
    // Add hover effect
    pauseButton.on('pointerover', () => {
      pauseButton.setTint(0x5a6c7d); // Lighter gray on hover
      this.tweens.add({
        targets: [pauseButton, pauseSymbol],
        scaleX: 1.1,
        scaleY: 1.1,
        duration: 200,
        ease: 'Power2.easeOut'
      });
    });
    
    pauseButton.on('pointerout', () => {
      pauseButton.setTint(0x34495e); // Back to original color
      this.tweens.add({
        targets: [pauseButton, pauseSymbol],
        scaleX: 1.0,
        scaleY: 1.0,
        duration: 200,
        ease: 'Power2.easeOut'
      });
    });
    
    // Add subtle hovering animation similar to bestiary
    this.tweens.add({
      targets: [pauseButton, pauseSymbol],
      y: pauseButton.y - 3, // Move up 3 pixels (less than bestiary's 5)
      duration: 2500, // Slightly different timing than bestiary
      ease: 'Sine.easeInOut',
      yoyo: true,
      repeat: -1,
      delay: 500 // Start with a delay to offset from bestiary animation
    });
  }

  private handlePlungerResult(result: 'green' | 'red' | 'yellow') {
    switch (result) {
      case 'green':
        // Success: Decrement flush count by 2 and spawn random tier 2 item
        this.FlushCount = Math.max(0, this.FlushCount - 2)
        this.updateToiletSprite()
        this.spawnTier2Reward()
        break
        
      case 'red':
        // Failure: Decrement flush count by 1 and spawn Unstable Goo
        this.FlushCount = Math.max(0, this.FlushCount - 1)
        this.updateToiletSprite()
        
        // Spawn Unstable Goo from portal as penalty
        this.events.emit('toilet:penalty', 'Unstable Goo')
        break
        
      case 'yellow':
        // Neutral: Decrement flush count by 1 only
        this.FlushCount = Math.max(0, this.FlushCount - 1)
        this.updateToiletSprite()
        break
    }

    // Handle toilet fixing and plunger movement if toilet becomes completely unclogged
    if (this.FlushCount <= 0) {
      // Ensure FlushCount is exactly 0, not negative
      this.FlushCount = 0
      this.updateToiletSprite()
      
      this.stopPlungerVibrateTimer()
      this.events.emit('toilet:fixed')
      
      // Move plunger back after sound finishes
      const soundDuration = this.plungerSound.totalDuration * 1000
      const bufferTime = 200
      
      this.time.delayedCall(soundDuration + bufferTime, () => {
        this.movePlungerToOriginalPosition()
        
        // Spawn a new box after toilet is unclogged and plunger is moved back
        this.time.delayedCall(1000, () => {
          this.boxSpawner.spawnBox()
        })
      })
    }
  }

  private spawnTier2Reward() {
    // Get all tier 2 items from the merge data
    const tier2Items = this.getTier2Items()
    
    if (tier2Items.length > 0) {
      // Pick a random tier 2 item
      const randomTier2 = tier2Items[Math.floor(Math.random() * tier2Items.length)]
      
      // Spawn it from the portal as a reward
      this.events.emit('toilet:merged', randomTier2)
    }
  }

  private getTier2Items(): string[] {
    // Import the merge data to get tier information
    const { ITEM_TIERS } = require('../config/mergeDataFull')
    
    const tier2Items: string[] = []
    
    // Find all items with tier 2
    for (const [itemName, tier] of Object.entries(ITEM_TIERS)) {
      if (tier === 2) {
        tier2Items.push(itemName)
      }
    }
    
    return tier2Items
  }

  private setupHintButton() {
    // Create hint button in top-left corner
    this.hintButton = new HintButton(this)
    this.hintButton.setPosition(80, 80) // Position in top-left area
  }

  private setupMergeSystem() {
    // Define toilet merge zone position (around the toilet sprite)
    const toiletZone = { 
      x: this.toilet.x, 
      y: this.toilet.y, 
      w: 140, 
      h: 140 
    };

    // Initialize the merge system without portal sprite initially
    const merge = initMergeCore(this, null, toiletZone);
    
    // Store merge system reference for towel functionality
    (this as any).mergeSystem = merge;

    // Initialize box spawner
    this.boxSpawner = new BoxSpawner(this, merge.items);

    // Listen for successful toilet merges
    this.events.on("toilet:merged", (resultName: string) => {
      // Check if this is the tutorial merge (Battery + Loose Wires = Powered Wire)
      if (this.tutorialPhase && resultName === "Powered Wire") {
        this.handleTutorialMerge();
      } else if (!this.tutorialPhase) {
        // Normal gameplay - send merged item to portal
        merge.spawner.spawnAtPortal(resultName);
      }
    });

    // Wait for all assets to be loaded AND give extra time for texture cache to be ready
    merge.items.getAssetManager().loadAllAssets().then(() => {
      // Add a small delay to ensure all textures are properly cached
      this.time.delayedCall(500, () => {
        // Don't start portal spawner during tutorial
        if (!this.tutorialPhase) {
          merge.spawner.start(5000); // Spawn tier 1 items every 5 seconds
        }
        
        // Initialize tier 1 count for the box spawner monitoring
        this.time.delayedCall(1000, () => {
          // Force an initial check to set the baseline
          if (this.boxSpawner && (this.boxSpawner as any).checkTier1Items) {
            (this.boxSpawner as any).checkTier1Items();
          }
        });
      });
    });

    // Spawn the initial box after a short delay
    this.time.delayedCall(2000, () => {
      this.boxSpawner.spawnBox();
    });
  }

  private handleTutorialMerge() {
    // Tutorial merge completed - create and animate portal
    this.createTutorialPortal();
  }

  private createTutorialPortal() {
    if (this.portalCreated) return;
    
    this.portalCreated = true;
    
    // Create portal animation - forward then backward (34 frames total, ignoring last 2)
    const forwardFrames = []
    const backwardFrames = []
    
    // Add forward frames (0-33, skipping the last 2 blank frames)
    for (let i = 0; i < 34; i++) {
      forwardFrames.push({ key: 'portal', frame: i })
    }
    
    // Add backward frames (32-1) to avoid duplicating frame 33 and frame 0
    for (let i = 32; i >= 1; i--) {
      backwardFrames.push({ key: 'portal', frame: i })
    }
    
    this.anims.create({
      key: 'portalAnim',
      frames: [...forwardFrames, ...backwardFrames],
      frameRate: 12,
      repeat: -1 // Loop infinitely
    })

    // Create the portal sprite at specified position - start very small
    const portal = this.add.sprite(564.96, 52.41, 'portal')
    portal.setDisplaySize(0, 0) // Start at size 0
    portal.setFlipY(true)
    portal.setName('portal') // Add name so we can find it later
    portal.play('portalAnim')

    // Animate portal growing to full size
    this.tweens.add({
      targets: portal,
      displayWidth: 600,
      displayHeight: 200,
      duration: 2000, // 2 seconds to grow
      ease: 'Back.easeOut',
      onComplete: () => {
        // Portal is now fully grown - update merge system and spawn tutorial items
        this.setupPortalInMergeSystem(portal);
        this.spawnTutorialItems();
      }
    });
  }

  private setupPortalInMergeSystem(portalSprite: Phaser.GameObjects.Sprite) {
    // Update the merge system with the portal sprite
    const merge = this.getMergeSystem();
    if (merge) {
      // Create a new spawner since we didn't have one during tutorial
      const { PortalSpawner } = require('../objects/mergeCore');
      const newSpawner = new PortalSpawner(this, merge.items, portalSprite);
      
      // Set the spawner in the merge system
      merge.spawner = newSpawner;
      
      // Initialize the spawner's mouth position
      (newSpawner as any).initMouth();
    }
  }

  private spawnTutorialItems() {
    // Spawn "Powered Wire" and "Unstable Goo" from the portal
    const merge = this.getMergeSystem();
    if (merge && merge.spawner) {
      console.log("Spawning tutorial items from portal");
      
      // Spawn Powered Wire first
      merge.spawner.spawnAtPortal("Powered Wire");
      
      // Spawn Unstable Goo after a short delay
      this.time.delayedCall(1500, () => {
        if (merge.spawner) {
          merge.spawner.spawnPenaltyItem("Unstable Goo");
          
          // Complete tutorial after both items are spawned
          this.time.delayedCall(2000, () => {
            this.completeTutorial();
          });
        }
      });
    } else {
      console.error("Merge system or spawner not available for tutorial items");
      console.log("Merge system:", merge);
      console.log("Spawner:", merge?.spawner);
      
      // Fallback: complete tutorial anyway
      this.time.delayedCall(1000, () => {
        this.completeTutorial();
      });
    }
  }

  private completeTutorial() {
    this.tutorialPhase = false;
    
    // Start normal portal spawning
    const merge = this.getMergeSystem();
    if (merge && merge.spawner) {
      merge.spawner.start(5000); // Spawn tier 1 items every 5 seconds
    }
    
    // Show tutorial completion message
    const message = this.add.text(this.scale.width / 2, this.scale.height / 2, 
      "Tutorial Complete!\nNormal gameplay begins now.", {
      fontSize: "24px",
      color: "#27ae60",
      backgroundColor: "#000000",
      padding: { x: 20, y: 10 },
      align: "center"
    });
    message.setOrigin(0.5);
    message.setDepth(3000);
    
    // Fade out message after 3 seconds
    this.time.delayedCall(3000, () => {
      this.tweens.add({
        targets: message,
        alpha: 0,
        duration: 1000,
        onComplete: () => message.destroy()
      });
    });
  }

  private startToiletPulsing() {
    // Don't start pulsing if toilet is already pulsing or if it's clogged
    if (this.toiletPulseTween || this.FlushCount >= 4) return;

    // Store the current scale values when effects are added
    const currentScaleX = this.toilet.scaleX;
    const currentScaleY = this.toilet.scaleY;

    // Add pulsing animation to the toilet - same pattern as box pulse effect
    this.toiletPulseTween = this.tweens.add({
      targets: this.toilet,
      scaleX: currentScaleX * 1.25, // Same multiplier as pulsing items
      scaleY: currentScaleY * 1.25, // Same multiplier as pulsing items
      duration: 625, // Same duration as pulsing items
      ease: 'Sine.easeInOut',
      yoyo: true,
      repeat: -1
    });

    // Stop pulsing after 10 seconds or when toilet is used
    this.time.delayedCall(10000, () => {
      this.stopToiletPulsing();
    });
  }

  private stopToiletPulsing() {
    if (this.toiletPulseTween) {
      this.toiletPulseTween.destroy();
      this.toiletPulseTween = undefined;
    }
  }

  private playToiletSound() {
    const currentTime = this.time.now
    
    // Stop toilet pulsing when toilet is clicked
    this.stopToiletPulsing();
    
    // If toilet is clogged (FlushCount >= 4), only shake - no sound or increment
    if (this.FlushCount >= 4) {
      this.shakeToilet()
      return
    }
    
    // Check if enough time has passed since the last sound play
    if (currentTime - this.lastToiletSoundTime >= this.TOILET_SOUND_COOLDOWN) {
      this.toiletSound.play()
      this.lastToiletSoundTime = currentTime
      
      // Check if toilet has any items (1 or more) BEFORE emitting flush event
      const merge = this.getMergeSystem()
      const hasAnyItems = merge && merge.toilet && merge.toilet.hasAnyItems()
      
      // Increment flush count if there are any items in the toilet (1 or more)
      if (hasAnyItems) {
        this.FlushCount++
        this.updateToiletSprite()
        
        // Move plunger closer to toilet when it gets clogged
        if (this.FlushCount >= 4) {
          this.movePlungerToToilet()
        }
      }
      
      // Emit flush event for merge system AFTER checking and incrementing flush count
      this.events.emit("toilet:flush")
      
      // Always shake the toilet when flushed, regardless of items
      this.shakeToilet()
    }
  }

  private usePlunger() {
    // Only work if toilet is clogged
    if (this.FlushCount <= 0) return
    
    const currentTime = this.time.now
    
    // Play plunger sound with cooldown (only when plunger is ready to use)
    if (currentTime - this.lastPlungerSoundTime >= this.PLUNGER_SOUND_COOLDOWN) {
      this.plungerSound.play()
      this.lastPlungerSoundTime = currentTime
    }
    
    // Launch the plunge mini-game - let the mini-game handle flush count changes
    this.scene.pause() // Pause the main game
    this.scene.launch('PlungeMiniGame', {
      toiletX: this.toilet.x,
      toiletY: this.toilet.y
    })
    
    // Shake plunger to show it's being used
    this.shakePlunger()
    
    // Remove the automatic toilet fixing logic - mini-game will handle this
    // The mini-game will call the appropriate methods based on the result
  }

  private setupPlunger() {
    // Position plunger to the right of the sink
    this.plungerOriginalX = 1050
    this.plungerOriginalY = 450
    
    this.plunger = this.physics.add.staticSprite(this.plungerOriginalX, this.plungerOriginalY, 'plunger')
    this.plunger.setDisplaySize(120, 120)
    this.plunger.setName('plunger')
    
    // Set up physics body
    this.plunger.body.setSize(120, 120)
    this.plunger.body.setOffset(-60, -60)
    
    // Start with plunger NOT interactive (disable interactivity properly)
    this.plunger.removeInteractive()
    
    // Add click handler that will only work when plunger is interactive
    this.plunger.on('pointerdown', () => {
      this.usePlunger()
    })
  }

  private movePlungerToToilet() {
    // Move plunger to specific coordinates when toilet is clogged
    const targetX = 873.00
    const targetY = 342.00
    
    this.tweens.add({
      targets: this.plunger,
      x: targetX,
      y: targetY,
      duration: 1000,
      ease: 'Power2',
      onComplete: () => {
        // Make plunger interactive only when it reaches the toilet
        this.plunger.setInteractive()
      }
    })
    
    // Start vibration timer when plunger is moved to toilet
    this.startPlungerVibrateTimer()
  }

  private movePlungerToOriginalPosition() {
    // Make plunger unclickable immediately when starting to move back
    this.plunger.removeInteractive()
    
    // Move plunger back to original position when toilet is fixed
    this.tweens.add({
      targets: this.plunger,
      x: this.plungerOriginalX,
      y: this.plungerOriginalY,
      duration: 1500,
      ease: 'Power2'
      // Plunger remains non-interactive at original position
    })
  }

  private startPlungerVibrateTimer() {
    // Stop existing timer if it exists
    this.stopPlungerVibrateTimer()
    
    // Only start timer if toilet needs fixing
    if (this.FlushCount <= 0) return
    
    // Create timer that vibrates plunger every 3 seconds
    this.plungerVibrateTimer = this.time.addEvent({
      delay: 3000, // 3 seconds
      callback: () => {
        // Only vibrate if toilet still needs fixing
        if (this.FlushCount > 0) {
          this.vibratePlunger()
        } else {
          this.stopPlungerVibrateTimer()
        }
      },
      loop: true
    })
  }

  private stopPlungerVibrateTimer() {
    if (this.plungerVibrateTimer) {
      this.plungerVibrateTimer.destroy()
      this.plungerVibrateTimer = null!
    }
  }

  private shakePlunger() {
    if (!this.plunger) return

    // Store current position
    const currentX = this.plunger.x
    const currentY = this.plunger.y

    // Create a quick shake effect for the plunger
    let shakeIntensity = 6
    const shakeDuration = 800 // Shorter shake for plunger
    const shakeInterval = 40

    // Function to update shake position
    const updateShake = () => {
      const randomX = currentX + Phaser.Math.Between(-shakeIntensity, shakeIntensity)
      const randomY = currentY + Phaser.Math.Between(-shakeIntensity, shakeIntensity)
      this.plunger.setPosition(randomX, randomY)
    }

    // Start the shaking timer
    const shakeTimer = this.time.addEvent({
      delay: shakeInterval,
      callback: updateShake,
      repeat: (shakeDuration / shakeInterval) - 1
    })

    // Stop shaking and reset position
    this.time.delayedCall(shakeDuration, () => {
      shakeTimer.destroy()
      this.plunger.setPosition(currentX, currentY)
    })
  }

  private vibratePlunger() {
    if (!this.plunger) return

    // Store current position
    const currentX = this.plunger.x
    const currentY = this.plunger.y

    // Create a subtle vibration effect
    let vibrateIntensity = 3 // Small vibration (3 pixels)
    const vibrateDuration = 500 // Half second vibration
    const vibrateInterval = 30 // Update every 30ms for smooth vibration

    // Function to update vibration position
    const updateVibration = () => {
      const randomX = currentX + Phaser.Math.Between(-vibrateIntensity, vibrateIntensity)
      const randomY = currentY + Phaser.Math.Between(-vibrateIntensity, vibrateIntensity)
      this.plunger.setPosition(randomX, randomY)
    }

    // Start the vibration timer
    const vibrateTimer = this.time.addEvent({
      delay: vibrateInterval,
      callback: updateVibration,
      repeat: (vibrateDuration / vibrateInterval) - 1
    })

    // Stop vibrating and reset position
    this.time.delayedCall(vibrateDuration, () => {
      vibrateTimer.destroy()
      this.plunger.setPosition(currentX, currentY)
    })
  }

  private updateToiletSprite() {
    if (!this.toilet) return
    
    // Determine which toilet texture to use based on FlushCount
    let textureKey = 'toilet' // Default (FlushCount = 0)
    
    if (this.FlushCount === 1) {
      textureKey = 'toilet1'
    } else if (this.FlushCount === 2) {
      textureKey = 'toilet2'
    } else if (this.FlushCount === 3) {
      textureKey = 'toilet3'
    } else if (this.FlushCount >= 4) {
      textureKey = 'toilet4'
    }
    
    // Update the toilet texture
    this.toilet.setTexture(textureKey)
  }

  private shakeToilet() {
    if (!this.toilet) return

    // Store original position
    const originalX = this.toilet.x
    const originalY = this.toilet.y

    // Create a variable to track shake intensity that decreases over time
    let shakeIntensity = 8 // Start with strong shake (8 pixels)
    const minIntensity = 0.5 // End with very light shake (0.5 pixel)
    const shakeDuration = 6000 // 6 seconds total
    const shakeInterval = 50 // Update every 50ms

    // Function to update shake position
    const updateShake = () => {
      const randomX = originalX + Phaser.Math.Between(-shakeIntensity, shakeIntensity)
      const randomY = originalY + Phaser.Math.Between(-shakeIntensity, shakeIntensity)
      this.toilet.setPosition(randomX, randomY)
    }

    // Start the shaking timer
    const shakeTimer = this.time.addEvent({
      delay: shakeInterval,
      callback: updateShake,
      repeat: (shakeDuration / shakeInterval) - 1 // Total number of shakes
    })

    // Gradually reduce shake intensity over time
    const intensityTimer = this.time.addEvent({
      delay: 200, // Update intensity every 200ms
      callback: () => {
        // Gradually reduce intensity from 8 to 0.5 over 6 seconds
        const elapsed = 6000 - shakeTimer.getRemaining()
        const progress = elapsed / shakeDuration
        shakeIntensity = Math.max(minIntensity, 8 - (7.5 * progress))
      },
      repeat: (shakeDuration / 200) - 1
    })

    // Stop shaking and reset position after 6 seconds
    this.time.delayedCall(shakeDuration, () => {
      shakeTimer.destroy()
      intensityTimer.destroy()
      this.toilet.setPosition(originalX, originalY)
    })
  }

  private setupToilet() {
    // Create the toilet sprite to the left of the towel but closer
    // Moving 10px to the left from previous position (867.68 - 10 = 857.68)
    this.toilet = this.physics.add.staticSprite(857.68, 380.70, 'toilet')
    this.toilet.setDisplaySize(200.00, 200.00)
    this.toilet.setName('toilet') // Set name so we can find it later
    
    // Set up physics body for collision detection
    this.toilet.body.setSize(200, 200)
    this.toilet.body.setOffset(-100, -100) // Center the physics body
    
    // Make toilet interactive and add click handler
    this.toilet.setInteractive()
    this.toilet.on('pointerdown', () => {
      this.playToiletSound()
    })
  }

  private setupSink() {
    // Create the sink sprite at the specified position and size
    const sink = this.physics.add.staticSprite(1121.33, 419.08, 'sink')
    sink.setDisplaySize(200.00, 200.00)
    sink.setName('sink')
    
    // Set up physics body
    sink.body.setSize(200, 200)
    sink.body.setOffset(-100, -100)
  }

  private setupTowel() {
    // Create the towel sprite at the specified position and size
    const towel = this.physics.add.staticSprite(967.68, 363.52, 'towel')
    towel.setDisplaySize(131.22, 131.22)
    towel.setName('towel')
    
    // Set up physics body
    towel.body.setSize(131.22, 131.22)
    towel.body.setOffset(-65.61, -65.61)
    
    // Make towel interactive and add click handler
    towel.setInteractive()
    towel.on('pointerdown', () => {
      this.onTowelClick()
    })
  }

  private onTowelClick() {
    // Only work if toilet is not clogged (FlushCount is 0, meaning toilet is clean)
    // When FlushCount is 0, the plunger is not active, so toilet is not clogged
    if (this.FlushCount > 0) return // If FlushCount > 0, toilet is clogged, don't spawn items
    
    // Get all existing tier 1 items on the field
    const existingTier1Items = this.getExistingTier1Items()
    
    // Check if there are any valid combinations among existing items
    if (this.hasValidTier1Combinations(existingTier1Items)) return
    
    // If no valid combinations exist, spawn a compatible item
    this.spawnCompatibleTier1Item(existingTier1Items)
  }

  private getExistingTier1Items(): string[] {
    const tier1Items: string[] = []
    
    // Get all items from the scene that have itemName property
    this.children.list.forEach(child => {
      if ((child as any).itemName) {
        const itemName = (child as any).itemName
        // Check if it's a tier 1 item using the merge data
        if (this.isTier1Item(itemName)) {
          tier1Items.push(itemName)
        }
      }
    })
    
    return tier1Items
  }

  private isTier1Item(itemName: string): boolean {
    // Import the tier 1 check from merge data
    const { isTier1 } = require('../config/mergeDataFull')
    return isTier1(itemName)
  }

  private hasValidTier1Combinations(tier1Items: string[]): boolean {
    const { getMergeResult } = require('../config/mergeDataFull')
    
    // Check all pairs of existing tier 1 items
    for (let i = 0; i < tier1Items.length; i++) {
      for (let j = i + 1; j < tier1Items.length; j++) {
        const result = getMergeResult(tier1Items[i], tier1Items[j])
        if (result) {
          return true // Found at least one valid combination
        }
      }
    }
    
    return false // No valid combinations found
  }

  private spawnCompatibleTier1Item(existingTier1Items: string[]) {
    if (existingTier1Items.length === 0) {
      // If no tier 1 items exist, spawn a random one
      const { pickRandomTier1 } = require('../config/mergeDataFull')
      const randomItem = pickRandomTier1()
      this.spawnItemFromTowel(randomItem)
      return
    }
    
    const { getTier1Partners, SPAWNABLE_TIER1 } = require('../config/mergeDataFull')
    
    // Find all possible partners for existing items
    const possiblePartners: string[] = []
    
    existingTier1Items.forEach(existingItem => {
      const partners = getTier1Partners(existingItem)
      partners.forEach(partner => {
        if (!possiblePartners.includes(partner) && !existingTier1Items.includes(partner)) {
          possiblePartners.push(partner)
        }
      })
    })
    
    if (possiblePartners.length > 0) {
      // Spawn a random compatible partner
      const randomPartner = possiblePartners[Math.floor(Math.random() * possiblePartners.length)]
      this.spawnItemFromTowel(randomPartner)
    } else {
      // Fallback: spawn any spawnable tier 1 item
      const availableItems = SPAWNABLE_TIER1.filter(item => !existingTier1Items.includes(item))
      if (availableItems.length > 0) {
        const randomItem = availableItems[Math.floor(Math.random() * availableItems.length)]
        this.spawnItemFromTowel(randomItem)
      }
    }
  }

  private spawnItemFromTowel(itemName: string) {
    // Get reference to the merge system's item manager
    const merge = this.getMergeSystem()
    if (!merge) return
    
    // Spawn item behind the towel (slightly to the left)
    const towelX = 967.68
    const towelY = 363.52
    const spawnX = towelX - 80 // Spawn 80 pixels to the left of towel
    const spawnY = towelY
    
    const item = merge.items.spawn(itemName, spawnX, spawnY)
    
    // Animate item sliding out from behind towel
    this.tweens.add({
      targets: item,
      x: towelX + 100, // Slide to the right of towel
      duration: 800,
      ease: 'Power2.easeOut',
      onComplete: () => {
        // Then drop to floor level
        const floorY = 473 - 18 // Floor platform top minus half item height
        this.tweens.add({
          targets: item,
          y: floorY,
          duration: 400,
          ease: 'Power2.easeIn'
        })
      }
    })
    
    // Add slight rotation during slide
    this.tweens.add({
      targets: item,
      angle: 90,
      duration: 800,
      ease: 'Power1.easeOut'
    })
  }

  private getMergeSystem() {
    // Return reference to the merge system if available
    // This assumes the merge system is stored as a scene property
    return (this as any).mergeSystem || null
  }

  private setupNewSprite() {
    // Create animation for the new sprite (4 frames at 0.25 fps)
    this.anims.create({
      key: 'newSpriteAnim',
      frames: this.anims.generateFrameNumbers('newSprite', { start: 0, end: 3 }),
      frameRate: 0.25, // 0.25 frames per second (1 frame every 4 seconds)
      repeat: -1 // Loop forever
    })

    // Create the new sprite at specified position with exact dimensions - static, no interaction
    const newSprite = this.add.sprite(651.8026101141925, 186.97354614237588, 'newSprite', 0)
    newSprite.setDisplaySize(87.48137007449901, 47.135068652692226)
    newSprite.play('newSpriteAnim')
  }

  private setupBoxSpawner() {
    // Create a new BoxSpawner instance
    this.boxSpawner = new BoxSpawner(this)
  }

  private setupGlobalCustomCursor() {
    // Hide default cursor globally for the entire game
    this.input.setDefaultCursor('none')
    
    // Create initial cursor
    this.createCustomCursor()
    
    // Set up global pointer tracking that works across all scenes
    this.setupGlobalPointerTracking()
    
    // Listen for scene events to recreate cursor when overlays are launched
    this.sys.events.on('wake', () => {
      this.recreateCustomCursor()
    })
    
    this.sys.events.on('resume', () => {
      this.recreateCustomCursor()
    })
  }

  private createCustomCursor() {
    // Destroy existing cursor if it exists
    if (this.customCursor) {
      this.customCursor.destroy()
    }
    
    // Create custom cursor sprite with highest possible depth
    this.customCursor = this.add.sprite(0, 0, 'grabber', 0) // Frame 0 = normal state
    this.customCursor.setDepth(999999) // Maximum depth to stay above everything
    this.customCursor.setScrollFactor(0) // Don't move with camera
    this.customCursor.setVisible(true) // Always visible
    this.customCursor.setFlipY(true) // Flip the cursor vertically
  }

  private recreateCustomCursor() {
    // Public method to recreate cursor from other scenes
    this.createCustomCursor()
    
    // Restore cursor state if pointer was down
    if (this.isPointerDown && this.customCursor) {
      this.customCursor.setFrame(1)
    }
  }

  private setupGlobalPointerTracking() {
    // Get the game instance to set up truly global cursor tracking
    const game = this.sys.game
    
    // Track mouse movement globally across the entire game canvas
    const canvas = game.canvas
    
    const updateCursorPosition = (event: MouseEvent) => {
      if (!this.customCursor || !this.customCursor.active) return
      
      // Get the canvas bounds
      const rect = canvas.getBoundingClientRect()
      
      // Calculate position relative to canvas
      const x = event.clientX - rect.left
      const y = event.clientY - rect.top
      
      // Scale coordinates if canvas is scaled
      const scaleX = canvas.width / rect.width
      const scaleY = canvas.height / rect.height
      
      const scaledX = x * scaleX
      const scaledY = y * scaleY
      
      this.customCursor.setPosition(scaledX, scaledY)
      
      // Ensure cursor stays on top by constantly updating its depth
      this.customCursor.setDepth(999999) // Maximum depth
    }
    
    const updateCursorState = (isDown: boolean) => {
      if (!this.customCursor || !this.customCursor.active) return
      this.customCursor.setFrame(isDown ? 1 : 0) // Frame 1 = clicking, Frame 0 = normal
      // Ensure cursor stays on top when state changes
      this.customCursor.setDepth(999999) // Maximum depth
    }
    
    // Add global mouse event listeners to the canvas
    canvas.addEventListener('mousemove', updateCursorPosition)
    canvas.addEventListener('mousedown', () => updateCursorState(true))
    canvas.addEventListener('mouseup', () => updateCursorState(false))
    
    // Handle mouse enter/leave for cursor visibility
    canvas.addEventListener('mouseenter', () => {
      if (this.customCursor) {
        this.customCursor.setVisible(true)
        this.customCursor.setDepth(999999)
      }
    })
    
    canvas.addEventListener('mouseleave', () => {
      if (this.customCursor) this.customCursor.setVisible(false)
    })
    
    // Also keep the Phaser input handlers as backup for scenes that need them
    this.input.on('pointermove', (pointer: Phaser.Input.Pointer) => {
      if (this.customCursor) {
        this.customCursor.setPosition(pointer.x, pointer.y)
        this.customCursor.setDepth(999999) // Maximum depth
      }
    })
    
    this.input.on('pointerdown', () => {
      this.isPointerDown = true
      if (this.customCursor) {
        this.customCursor.setFrame(1) // Frame 1 = clicking state
        this.customCursor.setDepth(999999) // Maximum depth
      }
    })
    
    this.input.on('pointerup', () => {
      this.isPointerDown = false
      if (this.customCursor) {
        this.customCursor.setFrame(0) // Frame 0 = normal state
        this.customCursor.setDepth(999999) // Maximum depth
      }
    })

    // Add a timer to periodically ensure cursor stays on top
    this.time.addEvent({
      delay: 50, // Every 50ms for more frequent updates
      callback: () => {
        if (this.customCursor && this.customCursor.active) {
          this.customCursor.setDepth(999999) // Maximum depth
          
          // Also ensure cursor is in the correct scene and visible
          if (this.customCursor.scene !== this) {
            this.recreateCustomCursor()
          }
        }
      },
      loop: true
    })
  }

  private setupInputHandlers() {
    // Close overlay with Ctrl+Shift+I
    this.input.keyboard!.on('keydown', (event: KeyboardEvent) => {
      if (event.ctrlKey && event.shiftKey && event.key === 'I') {
        this.closeOverlay();
      }
    });

    // Close with Escape
    this.input.keyboard!.on('keydown-ESC', () => {
      this.closeOverlay();
    });

    // Close when clicking background
    this.background.on('pointerdown', () => {
      this.closeOverlay();
    });
  }

  private setupToiletPaperBackground() {
    // Create the toilet paper background sprite at the specified position
    const toiletPaperBg = this.add.sprite(750, 333, 'toilet_paper_asset')
    toiletPaperBg.setDisplaySize(80, 80)
    toiletPaperBg.setName('toilet_paper_background')
    toiletPaperBg.setDepth(-5) // Set low depth so it appears behind other objects
    
    // No physics body or interactivity - it's just a background decoration
  }

  private setupAnimatedBackground() {
    // Create animation using individual images
    this.anims.create({
      key: 'backgroundAnim',
      frames: [
        { key: 'bg1' },
        { key: 'bg2' },
        { key: 'bg3' },
        { key: 'bg4' }
      ],
      frameRate: 6, // 6 frames per second for faster animation
      repeat: -1 // Loop forever
    })

    // Create the animated background sprite
    const background = this.add.sprite(this.cameras.main.centerX, this.cameras.main.centerY, 'bg1')
    background.setDisplaySize(this.cameras.main.width, this.cameras.main.height) // Stretch to fit screen
    background.setDepth(-1000) // Put it behind everything
    background.play('backgroundAnim')
  }

  private setupCollisionEditorKey() {
    // Add F9 key listener to launch collision editor
    this.input.keyboard!.on('keydown-F9', () => {
      // Pause this scene and launch the collision editor
      this.scene.pause()
      this.scene.launch('CollisionEditor')
    })

    // Add Ctrl+Shift+I key listener to launch recipe overlay
    this.input.keyboard!.on('keydown', (event: KeyboardEvent) => {
      if (event.ctrlKey && event.shiftKey && event.key === 'I') {
        // Pause this scene and launch the recipe overlay
        this.scene.pause()
        this.scene.launch('RecipeOverlay')
        
        // Recreate cursor after a brief delay to ensure it's on top of the overlay
        this.time.delayedCall(100, () => {
          this.recreateCustomCursor()
        })
      }
    })

    // Add ESC key listener to launch pause menu
    this.input.keyboard!.on('keydown-ESC', () => {
      // Pause this scene and launch the pause menu
      this.scene.pause()
      this.scene.launch('PauseMenu')
    })
  }

  public destroy() {
    // Clean up hint button when scene is destroyed
    if (this.hintButton) {
      this.hintButton.destroy()
    }
    
    // Clean up custom cursor if it exists
    if (this.customCursor) {
      this.customCursor.destroy()
    }
    
    // Clean up box spawner if it exists
    if (this.boxSpawner) {
      this.boxSpawner.destroy()
    }
    
    // Clean up merge system if it exists
    if (this.mergeSystem) {
      this.mergeSystem.destroy()
    }
    
    // Clean up sound objects if they exist
    if (this.toiletSound) {
      this.toiletSound.destroy()
    }
    if (this.plungerSound) {
      this.plungerSound.destroy()
    }
    
    // Clean up physics world if it exists
    if (this.physics.world) {
      this.physics.world.destroy()
    }
    
    // Clean up scene events if they exist
    if (this.sys.events) {
      this.sys.events.off('wake')
      this.sys.events.off('resume')
    }
    
    // Clean up input handlers if they exist
    if (this.input) {
      this.input.off('pointermove')
      this.input.off('pointerdown')
      this.input.off('pointerup')
    }
    
    // Clean up time events if they exist
    if (this.time) {
      this.time.events.off('destroy')
    }
    
    // Clean up tweens if they exist
    if (this.tweens) {
      this.tweens.events.off('destroy')
    }
    
    // Clean up animations if they exist
    if (this.anims) {
      this.anims.events.off('destroy')
    }
    
    // Clean up scene if it exists
    if (this.scene) {
      this.scene.events.off('destroy')
    }
    
    // Clean up game if it exists
    if (this.game) {
      this.game.events.off('destroy')
    }
    
    // Clean up all other properties
    this.toilet = null
    this.plunger = null
    this.plungerOriginalX = 0
    this.plungerOriginalY = 0
    this.plungerVibrateTimer = null
    this.boxSpawner = null
    this.customCursor = null
    this.isPointerDown = false
    this.hintButton = null
    this.mergeSystem = null
    this.toiletSound = null
    this.plungerSound = null
    
    super.destroy()
  }
}