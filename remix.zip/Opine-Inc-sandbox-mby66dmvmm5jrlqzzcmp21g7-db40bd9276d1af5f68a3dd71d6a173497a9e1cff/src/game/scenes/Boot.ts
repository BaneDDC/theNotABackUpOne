
// src/game/scenes/Boot.ts

import { Scene } from "phaser";

export class Boot extends Scene {
  private loadingBar!: Phaser.GameObjects.Graphics;
  private loadingBarBg!: Phaser.GameObjects.Graphics;
  private loadingText!: Phaser.GameObjects.Text;
  private currentFileText!: Phaser.GameObjects.Text;
  private continueText!: Phaser.GameObjects.Text;
  private isLoadingComplete: boolean = false;
  private totalAssets: number = 0;
  private loadedAssets: number = 0;

  constructor() {
    super("Boot");
  }

  preload() {
    this.createLoadingScreen();
    this.loadAllAssets();
    this.setupLoadingEvents();
  }

  private createLoadingScreen() {
    const centerX = this.scale.width / 2;
    const centerY = this.scale.height / 2;

    // Background
    this.add.rectangle(centerX, centerY, this.scale.width, this.scale.height, 0x2c3e50);

    // Title
    const title = this.add.text(centerX, centerY - 150, "TOILET MERGE GAME", {
      fontSize: "48px",
      color: "#ffffff",
      fontStyle: "bold"
    });
    title.setOrigin(0.5);

    // Loading bar background
    this.loadingBarBg = this.add.graphics();
    this.loadingBarBg.fillStyle(0x34495e);
    this.loadingBarBg.fillRoundedRect(centerX - 200, centerY - 20, 400, 40, 10);

    // Loading bar
    this.loadingBar = this.add.graphics();

    // Loading text
    this.loadingText = this.add.text(centerX, centerY - 60, "Loading... 0%", {
      fontSize: "24px",
      color: "#ffffff"
    });
    this.loadingText.setOrigin(0.5);

    // Current file text
    this.currentFileText = this.add.text(centerX, centerY + 40, "", {
      fontSize: "16px",
      color: "#bdc3c7",
      wordWrap: { width: 600 }
    });
    this.currentFileText.setOrigin(0.5);

    // Continue text (initially hidden)
    this.continueText = this.add.text(centerX, centerY + 100, "Click to continue", {
      fontSize: "20px",
      color: "#27ae60",
      fontStyle: "bold"
    });
    this.continueText.setOrigin(0.5);
    this.continueText.setVisible(false);

    // Add blinking animation to continue text
    this.tweens.add({
      targets: this.continueText,
      alpha: 0.3,
      duration: 800,
      yoyo: true,
      repeat: -1
    });
  }

  private loadAllAssets() {
    // Count total assets for progress calculation
    this.totalAssets = this.getTotalAssetCount();

    // Load the individual background images
    this.load.image('bg1', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/generated-asset-y325clor3k7sgl1z30ajwn51-1.png-omFNFdYBZKMrfkDnpNjBXNPBeqAMbN.png');
    this.load.image('bg2', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/generated-asset-y325clor3k7sgl1z30ajwn51-2.png-ZbNJ6RRWHIRiqlo7UeNZvEnAvS8zZj.png');
    this.load.image('bg3', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/generated-asset-y325clor3k7sgl1z30ajwn51-3.png-jl1Pr5ArmCzxO5XnkkPkEgO1ehf1pR.png');
    this.load.image('bg4', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/generated-asset-y325clor3k7sgl1z30ajwn51-4.png-P15Xly4Z8u95svzTGjGDQDvZGbz5Gd.png');
    
    // Load the grabber cursor spritesheet
    this.load.spritesheet('grabber', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/grabber-lUJTyIWnq9CjliEl5ja6cxUFIeG2LM.png', {
      frameWidth: 50,
      frameHeight: 50
    });
    
    // Load the portal spritesheet
    this.load.spritesheet('portal', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/portal_spritesheet-tuu0GUj716OBvtpw0lhDcMaD1YrejO.png', {
      frameWidth: 256,
      frameHeight: 256
    });
    
    // Load the new spritesheet
    this.load.spritesheet('newSprite', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/generated-asset-y325clor3k7sgl1z30ajwn51%20%281%29-N0k0h97JQbjHMn2B6KTIbbaVgcQR4M.png', {
      frameWidth: 114,
      frameHeight: 86
    });
    
    // Load all toilet sprites
    this.load.image('toilet', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22toilet%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it-IKQiDYjmgMvxEJRt3rMo6ThQDqBDua.%20strait%20foreward%20front%20to%20back%20view-1');
    this.load.image('toilet1', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/generated-asset-otzan6hqekmr8y0mqte48xpc%20%281%29-1.png-8FmoeG5xdeVd1DLEd8rZ3CEuVDPqeY.png');
    this.load.image('toilet2', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/generated-asset-otzan6hqekmr8y0mqte48xpc%20%281%29-2.png-nkv4UxTBRWqW2lvAhqp0vAEh9tjYsv.png');
    this.load.image('toilet3', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/generated-asset-otzan6hqekmr8y0mqte48xpc%20%281%29-3.png-5RKT6lEsgJeuptGRSEoGgpOeeiwiJQ.png');
    this.load.image('toilet4', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/generated-asset-otzan6hqekmr8y0mqte48xpc%20%281%29-4.png-JwdcykiV8cLm8DCbgkDHJWg2G8X7xN.png');
    
    // Load the plunger sprite
    this.load.image('plunger', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Plunger%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-bq6jyw6EYmsBI3to7wVAZCVSDwOQ6K.5d-2');
    
    // Load the sink sprite
    this.load.image('sink', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22sink%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-IYyixzsfkoTJidTzy6KeYMMA0c9Plx.5d%0A-0');
    
    // Load the towel sprite
    this.load.image('towel', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Towel%22%20hanging%20on%20a%20rack%20no%20shadow%2C%20must%20have%20the%20name%20on%20it-rC0ib1ZmGm4LxGPUNb2RLZ7pob2pit.%20strait%20foreward%20view%20no%20face-2');
    
    // Load sounds
    this.load.audio('toiletFlush', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/foley-toilet-flush-without-tank-refill-238004-5QbPCVstF4Oln1bjmAlQVuNaOyf4fJ.mp3');
    this.load.audio('plungerSound', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/plunge1-41079-qDvqpVQX79raem2TiioLxoJI01dP5L.mp3');
    this.load.audio('splash1', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/splash1-ZhiBCgWV50qZwEnJcnc3xe0V8TXCJp.mp3');
    this.load.audio('splash2', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/splash2-KQSUDmq8LUv7hxqEUEQXS93tBQXuqu.mp3');
    this.load.audio('splash3', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/splash3-us9Pqt7kxSAJkVojZWspen5Dd1iUXb.mp3');
    
    // Load hint sounds
    this.load.audio('yikes', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/yikes-Vi54H0vzUClhbpF8o9H8dQs1KbAQMt.mp3');
    this.load.audio('terrible', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/terrible-r7pofktgQpHBDrrsOJAkhT6gYK42Wl.mp3');
    this.load.audio('sureabout', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/sureabout-OckNxXUPEpxGUHlr9eVuZorydeSoHW.mp3');
    this.load.audio('embarass', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/embarass-mtE8FA0viKOZ0gp2tQzqnHCZj6RU8M.mp3');
    this.load.audio('seriously', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/seriously-c0ofIrFZLOjS2Jv5VlPRbFozZsvKvH.mp3');
    
    // Load item assets
    this.load.image('mop_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Mop%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-0Rllm47amMc5FJ1YYSVppCf8Q9yVnx.5d-0');
    this.load.image('loose_wires_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Loose%20Wires%22%20%20just%20a%20pile%20of%20wires%2C%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-Dctj0vehiJJX4FhO2VEzZ6Prv6OnQU.5d-0');
    this.load.image('rubber_duck_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Rubber%20Duck%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-PvFuLRK9Kcr8se4WwSYmFuN2IHiklm.5d-0');
    this.load.image('sock_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Sock%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-CG0w8V233dGR4o0GCF9gIqlSUyBpQa.5d-0');
    this.load.image('duct_tape_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Duct%20Tape%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-ANR9sRNgmHPIETmpkLzRwmGIHs3VYt.5d-2');
    this.load.image('toolkit_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22tool%20kit%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-2X54S3bbRtpgilzkqU00fbE5q2Sjjm.5d-0');
    this.load.image('coolant_tank_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Coolant%20Tank%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-hD6ImhqB54Dmu1j2oBsyjTDYsVrsMn.5d%0A-2');
    this.load.image('screw_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22screw%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-EyHFsBrFmVc2xvpgUbrFwQ6LnfVD55.5d-3');
    this.load.image('wrench_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22wrench%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-vraJu89JpLdkyf9PTXQXrgjatOUwy2.5d-0');
    this.load.image('energy_canister_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Energy%20Canister%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-ucTd6MToNY5lCli6MjfsanFwA3m9Mv.5d-1');
    this.load.image('goldfish_bowl_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Goldfish%20Bowl%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-sTCZ7zS4vPyvNMcLFTcB2UuydfxlWq.5d-0');
    this.load.image('portal_shard_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Portal%20Shard%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-A6dp5dm7mZIq1qN5jfjWa5MTfjWuLH.5d-0');
    this.load.image('battery_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20-L6oEJkPsYhgclnv8Xw9FnK2Dw9tjPL.%20Rick%20and%20morty%20style%209%20volt%20battery%20no%20shadow%20no%20background-3');
    this.load.image('fuse_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Rick%20and%20morty%20style%20%22FUSE%22%20%28like%20one%20that%20goes%20in%20a%20car%5D%20no%20shadows%20no%20background-0-Sihn5vGQnoWdQmhlOFxnPBGZ2ogEeA');
    this.load.image('pipe_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20-NAJhLYKrYJ9giJEhZgoVCYDVxzQYrq.%20Rick%20and%20morty%20style%20pipe%20%28like%20a%20lead%20pipe%29%20no%20shadows%20no%20background-3');
    this.load.image('ham_sandwich_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Ham%20Sandwich%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-CG0w8V233dGR4o0GCF9gIqlSUyBpQa.5d-0');
    this.load.image('unstable_goo_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20-5oZXl4wPh90INtS5kNdVu2y4Rd5dJE.%20Rick%20and%20morty%20style%20unstable%20goo%20no%20shadows%20no%20background-0');
    this.load.image('soggy_paper_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Rick%20and%20morty%20style%20%22soggy%20toilet%20paper%22%20no%20people%20no%20shadows%20no%20background-1-yoD6JHs5ll309taZtzMspYarAxlrcm');
    this.load.image('powered_wire_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Rick%20and%20morty%20style%20bundle%20of%20%22Powered%20Wire%22%20electric%20wires%20with%20arcs%20of%20lightning%20arcs%20no%20shadows%20no%20background-0-NVLAh9ZxGlhZzcmcYW7gM8NImUl3US');
    this.load.image('thors_plunger_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Rick%20and%20morty%20style%20%22Shock%20Plunger%22%20a%20metal%20toilet%20plungers%20with%20electric%20arcs%20no%20shadows%20no%20background-3-T3NB9atfbZIGDiPymHCa4KhfowIqry');
    this.load.image('goo_splatter', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-A%20splatter%20of%20green%20goo%2C%20cartoonish-W0Mt5IcK1nXkRIovNFBL1di1KivaGP.%20It%20should%20look%20like%20it%20is%20on%20a%20flat%20surface%20below%20eye%20level%20in%20single%20point%20perspective-3');
    this.load.image('box_closed', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/box-IT6ZUgllN2DmODelgycfajoJdMD4Pn.png');
    this.load.image('box_open', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/boxopen-f6HGm3wgSIa7RZxKXYG5U5BsxyU6jm.png');
    this.load.image('fan_blade_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Fan%20Blade%22%20just%201%20blade%20not%20the%20entire%20fan%2C%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-KiTQpjpscu6qf12HqaP8K04JnPwF3y.5d-2');
    this.load.image('toilet_brush_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Toilet%20Brush%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-DHWilH7Hz2GgQJRwtgfyEuKTPFY0Pk.5d-0');
    this.load.image('toilet_paper_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20.%20a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Toilet%20Paper%22%20just%201%20blade%20not%20the%20entire%20fan%2C%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-SYJCbR1Py98sYB7Pw1VpaI0U0amrRA.5d-1');
    this.load.image('soap_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Soap%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-OSZesnJPp4UP0yLXcM8DIKcFUF0wkn.5d-0');
    this.load.image('bucket_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-a%20futuristic%2090s-00s%20rick%20and%20morty%20style%20%22Bucket%22%20no%20shadow%2C%20must%20have%20the%20name%20on%20it.%20side%20view%20not%202-6muHgpXHMdW2oMNtZReBU2GfxADs0S.5d-2');
    this.load.image('plunger_asset', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Chibi%20art%20style%20with%20no%20anthropomorphisms%20-9TGifL3Bo8Y1k2EJXnOaliJaEao7Po.%20Rick%20and%20morty%20style%20plunger%20with%20a%20face%20no%20shadow%20no%20ground%20no%20background-2');
    this.load.image('book_closed', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bg-removed-Rick%20and%20morty%20style%20%22bestiary%20book%22%20closed%2C%20%20no%20background%20no%20shadows-0-auUOBgFdket6BYZbF0UEYWGfkUujL6');
    this.load.image('book_open', 'https://1jnxxd5hmjmhwwrc.public.blob.vercel-storage.com/bestiaryopen-fm4h6KDMWUK1oywWIYryPTOXlyUKm0.png');
  }

  private getTotalAssetCount(): number {
    // Count all the assets we're loading
    return 50; // Updated from 45 to 50 to include the 5 new hint sounds
  }

  private setupLoadingEvents() {
    this.load.on('progress', (progress: number) => {
      this.updateLoadingBar(progress);
    });

    this.load.on('fileprogress', (file: any) => {
      this.updateCurrentFile(file.key);
    });

    this.load.on('complete', () => {
      // Set all loaded textures to use nearest neighbor filtering to prevent blurriness
      this.textures.each((key: string, texture: Phaser.Textures.Texture) => {
        // Add proper null checks before accessing texture source
        if (texture && texture.source && texture.source.length > 0 && texture.source[0]) {
          texture.source[0].setFilter(Phaser.Textures.FilterMode.NEAREST);
        }
      });
      
      this.onLoadComplete();
    });
  }

  private updateLoadingBar(progress: number) {
    const centerX = this.scale.width / 2;
    const centerY = this.scale.height / 2;
    const percentage = Math.round(progress * 100);

    // Update loading text
    this.loadingText.setText(`Loading... ${percentage}%`);

    // Update loading bar
    this.loadingBar.clear();
    this.loadingBar.fillStyle(0x27ae60);
    this.loadingBar.fillRoundedRect(centerX - 195, centerY - 15, 390 * progress, 30, 8);
  }

  private updateCurrentFile(fileName: string) {
    // Clean up the file name for display
    let displayName = fileName;
    
    // Convert asset keys to readable names
    const nameMap: { [key: string]: string } = {
      'bg1': 'Background Frame 1',
      'bg2': 'Background Frame 2', 
      'bg3': 'Background Frame 3',
      'bg4': 'Background Frame 4',
      'grabber': 'Cursor Sprite',
      'portal': 'Portal Animation',
      'newSprite': 'Decoration Sprite',
      'toilet': 'Toilet (Clean)',
      'toilet1': 'Toilet (Level 1)',
      'toilet2': 'Toilet (Level 2)',
      'toilet3': 'Toilet (Level 3)',
      'toilet4': 'Toilet (Clogged)',
      'plunger': 'Plunger Tool',
      'sink': 'Bathroom Sink',
      'towel': 'Towel Rack',
      'toiletFlush': 'Toilet Flush Sound',
      'plungerSound': 'Plunger Sound',
      'splash1': 'Splash Sound 1',
      'splash2': 'Splash Sound 2',
      'splash3': 'Splash Sound 3',
      'yikes': 'Hint Sound: Yikes',
      'terrible': 'Hint Sound: Terrible',
      'sureabout': 'Hint Sound: Sure About',
      'embarass': 'Hint Sound: Embarrass',
      'seriously': 'Hint Sound: Seriously',
      'mop_asset': 'Mop Item',
      'loose_wires_asset': 'Loose Wires Item',
      'rubber_duck_asset': 'Rubber Duck Item',
      'sock_asset': 'Sock Item',
      'duct_tape_asset': 'Duct Tape Item',
      'toolkit_asset': 'Toolkit Item',
      'coolant_tank_asset': 'Coolant Tank Item',
      'screw_asset': 'Screw Item',
      'wrench_asset': 'Wrench Item',
      'energy_canister_asset': 'Energy Canister Item',
      'goldfish_bowl_asset': 'Goldfish Bowl Item',
      'portal_shard_asset': 'Portal Shard Item',
      'battery_asset': 'Battery Item',
      'fuse_asset': 'Fuse Item',
      'pipe_asset': 'Pipe Item',
      'ham_sandwich_asset': 'Ham Sandwich Item',
      'unstable_goo_asset': 'Unstable Goo Enemy',
      'soggy_paper_asset': 'Soggy Paper Hazard',
      'powered_wire_asset': 'Powered Wire Item',
      'thors_plunger_asset': 'Thor\'s Plunger Item',
      'goo_splatter': 'Goo Splatter Effect',
      'box_closed': 'Closed Box',
      'box_open': 'Open Box',
      'fan_blade_asset': 'Fan Blade Item',
      'toilet_brush_asset': 'Toilet Brush Item',
      'toilet_paper_asset': 'Toilet Paper Item',
      'soap_asset': 'Soap Item',
      'bucket_asset': 'Bucket Item',
      'plunger_asset': 'Plunger Item',
      'book_closed': 'Bestiary Book (Closed)',
      'book_open': 'Bestiary Book (Open)'
    };

    displayName = nameMap[fileName] || fileName;
    this.currentFileText.setText(`Loading: ${displayName}`);
  }

  private onLoadComplete() {
    this.isLoadingComplete = true;
    this.loadingText.setText("Loading Complete!");
    this.currentFileText.setText("All assets loaded successfully");
    this.continueText.setVisible(true);

    // Make the screen clickable to continue
    this.input.once('pointerdown', () => {
      this.startGame();
    });

    // Also allow Enter key to continue
    this.input.keyboard!.once('keydown-ENTER', () => {
      this.startGame();
    });

    // Also allow Space key to continue
    this.input.keyboard!.once('keydown-SPACE', () => {
      this.startGame();
    });
  }

  private startGame() {
    // Load volume settings before starting the game
    this.loadVolumeSettings();
    
    // Fade out loading screen
    this.cameras.main.fadeOut(500, 0, 0, 0);
    
    this.cameras.main.once('camerafadeoutcomplete', () => {
      // Start the main game scene
      this.scene.start('Game');
    });
  }

  private loadVolumeSettings() {
    const saved = localStorage.getItem('game_volume');
    if (saved) {
      try {
        const volume = parseFloat(saved);
        this.game.sound.volume = Phaser.Math.Clamp(volume, 0, 1);
      } catch (e) {
        this.game.sound.volume = 1.0;
      }
    }
  }

  create() {
    // Scene is ready, loading will begin automatically
  }
}
