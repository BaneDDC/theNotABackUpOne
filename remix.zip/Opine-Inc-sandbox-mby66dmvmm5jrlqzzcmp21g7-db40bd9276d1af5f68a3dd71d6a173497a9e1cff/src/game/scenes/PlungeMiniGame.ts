
// src/game/scenes/PlungeMiniGame.ts

import { Scene } from "phaser";

export class PlungeMiniGame extends Scene {
  private toiletX: number = 0;
  private toiletY: number = 0;
  private targetCircle!: Phaser.GameObjects.Graphics;
  private needle!: Phaser.GameObjects.Graphics;
  private needleAngle: number = 0;
  private rotationSpeed: number = 2; // degrees per frame
  private rotationDirection: number = 1; // 1 for clockwise, -1 for counter-clockwise
  private isActive: boolean = true;
  
  // Zone configuration - randomized each game
  private greenStart: number = 0;
  private greenEnd: number = 0;
  private leftRedStart: number = 0;
  private leftRedEnd: number = 0;
  private rightRedStart: number = 0;
  private rightRedEnd: number = 0;

  constructor() {
    super("PlungeMiniGame");
  }

  init(data: { toiletX: number; toiletY: number }) {
    // Get toilet position from the data passed when launching the scene
    this.toiletX = data.toiletX || 0;
    this.toiletY = data.toiletY || 0;
    
    // Reset state for new mini-game
    this.needleAngle = 0;
    this.isActive = true;
    
    // Randomize rotation speed: base 2 degrees ± 0.5 degrees (1.5 to 2.5)
    this.rotationSpeed = 2 + (Math.random() - 0.5); // Random between 1.5 and 2.5
    
    // Randomly choose rotation direction
    this.rotationDirection = Math.random() < 0.5 ? 1 : -1; // 50% chance for each direction
    
    // Randomize zone configuration
    this.randomizeZones();
  }

  private randomizeZones() {
    // Randomize green zone size: 8% to 12% of circle (base 10% ± 2%)
    const minGreenSize = 28.8; // 8% of 360 degrees
    const maxGreenSize = 43.2; // 12% of 360 degrees
    const greenSize = Phaser.Math.Between(minGreenSize, maxGreenSize);
    
    // Randomize green zone position: anywhere around the circle
    const greenCenter = Phaser.Math.Between(0, 359);
    
    // Calculate green zone boundaries
    this.greenStart = greenCenter - (greenSize / 2);
    this.greenEnd = greenCenter + (greenSize / 2);
    
    // Normalize angles to 0-360 range
    if (this.greenStart < 0) this.greenStart += 360;
    if (this.greenEnd >= 360) this.greenEnd -= 360;
    
    // Red zones: 20% each = 72 degrees each
    // Position them on either side of the green zone
    if (this.greenStart < this.greenEnd) {
      // Normal case: green zone doesn't wrap around
      this.leftRedStart = this.greenStart - 72;
      this.leftRedEnd = this.greenStart;
      this.rightRedStart = this.greenEnd;
      this.rightRedEnd = this.greenEnd + 72;
      
      // Normalize red zone angles
      if (this.leftRedStart < 0) this.leftRedStart += 360;
      if (this.rightRedEnd >= 360) this.rightRedEnd -= 360;
    } else {
      // Green zone wraps around 0 degrees
      this.leftRedStart = this.greenStart - 72;
      this.leftRedEnd = this.greenStart;
      this.rightRedStart = this.greenEnd;
      this.rightRedEnd = this.greenEnd + 72;
      
      // Handle wrapping for red zones
      if (this.leftRedStart < 0) this.leftRedStart += 360;
      if (this.rightRedEnd >= 360) this.rightRedEnd -= 360;
    }
  }

  create() {
    // Set transparent background so we only see the mini-game elements
    this.cameras.main.setBackgroundColor('rgba(0,0,0,0)');
    
    // Create the target circle centered on toilet position
    this.createTargetCircle();
    
    // Create the rotating needle
    this.createNeedle();
    
    // Setup input handlers
    this.setupInputHandlers();
    
    // Start the needle rotation
    this.startNeedleRotation();
  }

  private createTargetCircle() {
    this.targetCircle = this.add.graphics();
    this.targetCircle.setDepth(3000); // High depth to appear above game elements
    
    // Draw the main target circle with colored zones
    const circleRadius = 80;
    const centerX = this.toiletX;
    const centerY = this.toiletY;
    
    // Convert to radians for drawing
    const toRad = (deg: number) => Phaser.Math.DegToRad(deg);
    
    // Draw yellow background (full circle first)
    this.targetCircle.fillStyle(0xf1c40f, 0.25); // Yellow with 25% opacity
    this.targetCircle.fillCircle(centerX, centerY, circleRadius);
    
    // Draw red zones
    this.targetCircle.fillStyle(0xe74c3c, 0.25); // Red with 25% opacity
    
    // Helper function to draw arc segment
    const drawArcSegment = (startAngle: number, endAngle: number) => {
      this.targetCircle.beginPath();
      this.targetCircle.moveTo(centerX, centerY);
      
      if (startAngle <= endAngle) {
        // Normal case: no wrapping
        this.targetCircle.arc(centerX, centerY, circleRadius, toRad(startAngle), toRad(endAngle));
      } else {
        // Wrapping case: draw two arcs
        this.targetCircle.arc(centerX, centerY, circleRadius, toRad(startAngle), toRad(360));
        this.targetCircle.arc(centerX, centerY, circleRadius, toRad(0), toRad(endAngle));
      }
      
      this.targetCircle.closePath();
      this.targetCircle.fillPath();
    };
    
    // Draw left red zone
    if (this.leftRedStart !== this.leftRedEnd) {
      drawArcSegment(this.leftRedStart, this.leftRedEnd);
    }
    
    // Draw right red zone  
    if (this.rightRedStart !== this.rightRedEnd) {
      drawArcSegment(this.rightRedStart, this.rightRedEnd);
    }
    
    // Draw green zone (success zone)
    this.targetCircle.fillStyle(0x2ecc71, 0.25); // Green with 25% opacity
    drawArcSegment(this.greenStart, this.greenEnd);
    
    // Draw outer ring (dark border)
    this.targetCircle.lineStyle(4, 0x2c3e50, 0.8);
    this.targetCircle.strokeCircle(centerX, centerY, circleRadius);
    
    // Center dot
    this.targetCircle.fillStyle(0x34495e, 0.9);
    this.targetCircle.fillCircle(centerX, centerY, 6);
    
    // Add zone divider lines for clarity
    this.targetCircle.lineStyle(2, 0x2c3e50, 0.6);
    
    // Draw lines at zone boundaries
    const drawRadiusLine = (angle: number) => {
      const rad = toRad(angle);
      const endX = centerX + Math.cos(rad) * circleRadius;
      const endY = centerY + Math.sin(rad) * circleRadius;
      this.targetCircle.lineBetween(centerX, centerY, endX, endY);
    };
    
    // Draw boundary lines
    drawRadiusLine(this.greenStart);  // Left edge of green zone
    drawRadiusLine(this.greenEnd);    // Right edge of green zone
    drawRadiusLine(this.leftRedStart); // Left edge of left red zone
    drawRadiusLine(this.rightRedEnd);  // Right edge of right red zone
  }

  private createNeedle() {
    this.needle = this.add.graphics();
    this.needle.setDepth(3001); // Above the target circle
    
    this.updateNeedlePosition();
  }

  private updateNeedlePosition() {
    if (!this.needle) return;
    
    this.needle.clear();
    
    // Calculate needle end position based on current angle
    const needleLength = 75; // Slightly shorter than circle radius
    const angleInRadians = Phaser.Math.DegToRad(this.needleAngle);
    
    const endX = this.toiletX + Math.cos(angleInRadians) * needleLength;
    const endY = this.toiletY + Math.sin(angleInRadians) * needleLength;
    
    // Draw the needle as a line from center to edge
    this.needle.lineStyle(3, 0xf39c12, 1.0);
    this.needle.lineBetween(this.toiletX, this.toiletY, endX, endY);
    
    // Add a small circle at the needle tip
    this.needle.fillStyle(0xf39c12, 1.0);
    this.needle.fillCircle(endX, endY, 4);
  }

  private startNeedleRotation() {
    // Use a timer event to rotate the needle continuously
    this.time.addEvent({
      delay: 16, // ~60 FPS
      callback: () => {
        if (this.isActive) {
          // Apply rotation speed and direction
          this.needleAngle += this.rotationSpeed * this.rotationDirection;
          
          // Normalize angle to 0-360 range
          if (this.needleAngle >= 360) {
            this.needleAngle -= 360;
          } else if (this.needleAngle < 0) {
            this.needleAngle += 360;
          }
          
          this.updateNeedlePosition();
        }
      },
      loop: true
    });
  }

  private setupInputHandlers() {
    // Handle left mouse click to stop the mini-game
    this.input.on('pointerdown', (pointer: Phaser.Input.Pointer) => {
      if (pointer.leftButtonDown()) {
        this.stopMiniGame();
      }
    });
    
    // Also handle ESC key as alternative way to close
    this.input.keyboard!.on('keydown-ESC', () => {
      this.stopMiniGame();
    });
  }

  private stopMiniGame() {
    if (!this.isActive) return;
    
    this.isActive = false;
    
    // Determine the result based on current needle zone
    const currentZone = this.getCurrentZone();
    
    // Add a brief visual feedback before closing
    this.tweens.add({
      targets: [this.targetCircle, this.needle],
      alpha: 0,
      scaleX: 1.2,
      scaleY: 1.2,
      duration: 200,
      ease: 'Power2.easeOut',
      onComplete: () => {
        this.closeMiniGame(currentZone);
      }
    });
  }

  private closeMiniGame(result?: 'green' | 'red' | 'yellow') {
    // Send result back to the main game scene via events
    if (result) {
      this.scene.get('Game').events.emit('plunger:result', result);
    }
    
    // Resume the main game scene
    this.scene.resume('Game');
    
    // Stop this mini-game scene
    this.scene.stop();
  }

  // Method to get current needle angle (for future success/fail logic)
  public getCurrentNeedleAngle(): number {
    return this.needleAngle;
  }

  // Method to determine which zone the needle is currently in
  public getCurrentZone(): 'green' | 'red' | 'yellow' {
    // Normalize angle to 0-360 range
    let normalizedAngle = this.needleAngle % 360;
    if (normalizedAngle < 0) normalizedAngle += 360;
    
    // Helper function to check if angle is within a zone (handles wrapping)
    const isInZone = (angle: number, start: number, end: number): boolean => {
      if (start <= end) {
        // Normal case: no wrapping
        return angle >= start && angle <= end;
      } else {
        // Wrapping case: angle is either >= start OR <= end
        return angle >= start || angle <= end;
      }
    };
    
    // Check green zone
    if (isInZone(normalizedAngle, this.greenStart, this.greenEnd)) {
      return 'green';
    }
    
    // Check red zones
    if (isInZone(normalizedAngle, this.leftRedStart, this.leftRedEnd) ||
        isInZone(normalizedAngle, this.rightRedStart, this.rightRedEnd)) {
      return 'red';
    }
    
    // Everything else is yellow
    return 'yellow';
  }

  // Method to set rotation speed (for difficulty adjustment)
  public setRotationSpeed(speed: number) {
    this.rotationSpeed = speed;
  }

  destroy() {
    // Clean up graphics objects
    if (this.targetCircle) {
      this.targetCircle.destroy();
    }
    if (this.needle) {
      this.needle.destroy();
    }
    
    // Clean up input handlers
    this.input.removeAllListeners();
    if (this.input.keyboard) {
      this.input.keyboard.removeAllListeners();
    }
    
    super.destroy();
  }
}